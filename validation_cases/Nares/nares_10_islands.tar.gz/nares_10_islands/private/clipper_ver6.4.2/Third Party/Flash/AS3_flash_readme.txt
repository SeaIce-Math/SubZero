An AS3 Flash port written by Chris Denham:
https://github.com/ChrisDenham/PolygonClipper.AS3
