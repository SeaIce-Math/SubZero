function c2_boundary =initialize_boundaries_Nares()

%Adding walls around the domain
% Lx=1e5; Ly=1e5;
% x=[-1 -1 1 1 -1]*Lx; 
% y=[-1 1 1 -1 -1]*Ly;

%%Inertial
% R = 65e4;
% t = 0:pi/50:2*pi;
% x = R*cos(t); y = R*sin(t);

%%Nares
% Lx=4.5e5; Ly=3.5e5;
% x=[-1 -1 0 0 2 1  1 -1]*Lx; 
% y=[-1  1 1 2 2 1 -1 -1 ]*Ly;

%%Nares Channel
Lx=1e5; Ly=7.5e5;
x=[-1 -1 1 1 -1]*Lx;
y=[-1 1 1 -1 -1]*Ly;


c2_boundary = [x; y];


end