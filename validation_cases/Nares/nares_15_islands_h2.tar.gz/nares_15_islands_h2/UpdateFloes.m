paths
load('FloeStartIslands.mat','Floe','Nb');
for ii =1:length(Floe)
    if Floe(ii).Yi < 0
        height.mean = 1.5; %mean value of thickness for initial floes
        height.delta = 0; %maximum deviation about the mean thickness if a distribution is desired
    else 
        height.mean = 2; %mean value of thickness for initial floes
        height.delta = 0; %maximum deviation about the mean thickness if a distribution is desired
    end
    poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
    FloeNEW = initialize_floe_values(poly, height);
    Floe(ii) = FloeNEW;
end
save('FloeStartIslands.mat','Floe','Nb');

height.mean = 2; %mean value of thickness for initial floes
height.delta = 0; %maximum deviation about the mean thickness if a distribution is desired
load('FloeFill.mat','FloeFill');
for ii =1:length(FloeFill)
    poly = polyshape(FloeFill(ii).c_alpha'+[FloeFill(ii).Xi FloeFill(ii).Yi]);
    FloeNEW = initialize_floe_values(poly, height);
    FloeNEW=rmfield(FloeNEW,{'poly'});
    FloeNEW=rmfield(FloeNEW,{'potentialInteractions'});
    FloeFill(ii) = FloeNEW;
end


save('FloeFill.mat','FloeFill');