
An Haskell module written by 	Chetan Taralekar <chetant@gmail.com>
that wraps the Clipper library can be downloaded from:
http://hackage.haskell.org/package/clipper
