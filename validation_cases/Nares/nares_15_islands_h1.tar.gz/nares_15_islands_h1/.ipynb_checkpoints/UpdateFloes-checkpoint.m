paths
load('FloeStartNoIslands.mat','Floe','Nb');
height.mean = 1.0; %mean value of thickness for initial floes
height.delta = 0; %maximum deviation about the mean thickness if a distribution is desired
for ii =1:length(Floe)
    poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
    FloeNEW = initialize_floe_values(poly, height);
    Floe(ii) = FloeNEW;
end


save('FloeStartNoIslands.mat','Floe','Nb');

load('FloeFill.mat','FloeFill');
for ii =1:length(FloeFill)
    poly = polyshape(FloeFill(ii).c_alpha'+[FloeFill(ii).Xi FloeFill(ii).Yi]);
    FloeNEW = initialize_floe_values(poly, height);
    FloeNEW=rmfield(FloeNEW,{'poly'});
    FloeNEW=rmfield(FloeNEW,{'potentialInteractions'});
    FloeFill(ii) = FloeNEW;
end


save('FloeFill.mat','FloeFill');