% ratio=Ly/Lx;
ratio=1.616;%max(ocean.Yo)/max(ocean.Xo);
%ratio = abs(-1.5e5)/(Lx); %Ly/Lx;%
if (fig==0 || ~isvalid(fig))
    fig=figure('Position',[10 10 200 200*ratio],'visible','on');  
    set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
end
figure(fig)
clf(fig);

dn=1; % plot every dn'th velocity vector
% quiver(ocean.Xo(1:dn:end),ocean.Yo(1:dn:end),ocean.Uocn(1:dn:end,1:dn:end),ocean.Vocn(1:dn:end,1:dn:end));
hold on;

axis([ocean.Xo(1) ocean.Xo(end) ocean.Yo(1) ocean.Yo(end)]);

colormap('gray'); caxis([0 1]);

% title(['Time = ' num2str(Time) ' s'],'fontsize',24);
for ii =1:length(Floe)
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
    Stress(ii) = max(abs(eig(Floe(ii).Stress)));
end

A = cat(1,Floe.area);

load('./plotting/NaresGLwide.mat'); %load('./plotting/NaresCAwide.mat'); %load('./plotting/NaresISwide.mat');% 
NaresIm2 = naresGLwide;%+naresCAwide+naresISwide;
%NaresIm2 = naresISwide;
col = [10    18    29];
for ii = 1:3
    in1 = NaresIm2(:,:,ii); in1(in1==0)=col(ii);
    NaresIm2(:,:,ii) = in1;
end
ny = 370; y1 = 984; nx = 243; x1 = 240;
Lx= max(c2_boundary_poly.Vertices(:,1)); %c2 must be symmetric around x=0 for channel boundary conditions.
Ly= max(c2_boundary_poly.Vertices(:,2)); 
x_nares=[-1 -1 1 1 -1]*Lx;
y_nares=[-1 1 1 -1 -1]*Ly;
xc = min(x_nares):(max(x_nares)-min(x_nares))/(nx-1):max(x_nares);
yc = min(y_nares):(max(y_nares)-min(y_nares))/(ny-1):max(y_nares);
yc = fliplr(yc);
nares = NaresIm2(y1:y1+ny,x1:x1+nx,:);
KennedyISwide = nares;
save('./plotting/KennedyGLwide.mat','KennedyGLwide','xc','yc')
%nares = NaresIm2;
image(xc,yc,nares)
set(gca, 'ydir', 'normal')
hold on; 
clear poly_bound
for iii = 1:Nb
    poly_bound(iii) = polyshape(Floe(iii).c_alpha'+[Floe(iii).Xi Floe(iii).Yi]);
end
plot(R,'FaceColor',[1 1 1],'FaceAlpha',0.5,'EdgeAlpha',0.5);
axis([-Lx Lx -Ly Ly])
%% 
B = load('arcticborderdata.mat'); 
% Unproject and reproject if necessary: 
for k = 1:length(x)
    Arctic(k) = polyshape(x{k},y{k});
end
Gl = Arctic(51);

%% 
close all
% figure
load('./FloesLarge.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
A_flux = A_total_flux+A_flux_tmp;
%A_flux = A_flux-A_flux(3); A_flux(1) = 0;A_flux(2) = 0;
A_flux = A_flux-A_flux(2); A_flux(1) = 0;
t = t_flux/24/3600;
% load('./Floe0000240.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
% A_flux_new = A_total_flux+A_f[lux_tmp;
% A_flux_new = A_flux_new-A_flux_new(3); A_flux(1) = 0;
% t_new = t_flux/24/3600;
% A_flux = [A_flux A_flux_new(3:end)+A_flux(end)];
% t = [t t_new(3:end)];
load('./FloeSmall0_4.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux2 = A_total_flux+A_flux_tmp;
%A_flux2 = A_flux2-A_flux2(3458); 
A_flux2 = A_flux2-A_flux2(3); A_flux2(1) = 0;A_flux2(2) = 0;
t2 = t_flux/24/3600;
% load('./Floe0000168.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
% A_flux_new = A_total_flux+A_flux_tmp;
% A_flux_new = A_flux_new-A_flux_new(3); A_flux(1) = 0;
% t_new = t_flux/24/3600;
% A_flux2 = [A_flux2 A_flux_new(3:end)+A_flux2(end)];
% t2 = [t2 t_new(3:end)];
load('./Floe0000493.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux3 = A_total_flux+A_flux_tmp;
%A_flux3 = A_flux3-A_flux3(3458);
A_flux3 = A_flux3-A_flux3(3); A_flux3(1) = 0;A_flux3(2) = 0;
t3 = t_flux/24/3600;
% load('./Floe0000569.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
% A_flux4 = A_total_flux+A_flux_tmp;
% A_flux4 = A_flux4-A_flux4(2); A_flux4(1) = 0;
% t4 = t_flux/24/3600;
% f_dif = A_flux3(3433)-A_flux3(3432); A_flux3(3433:end) = A_flux3(3433:end)-f_dif;
% A_flux3(5849:end) = A_flux3(5849:end)-f_dif;A_flux3(5850:end) = A_flux3(5850:end)-f_dif;
% A_flux3(5851:end) = A_flux3(5851:end)-f_dif;
i_flux_tot = 0; i_flux_tot2 = 0;
for kk = 2:length(i_flux)
    i_flux_tot(kk) = i_flux_tot(kk-1)+i_flux(kk)*(T_flux(kk)-T_flux(kk-1))*1e6;
    i_flux_tot2(kk) = trapz(T_flux(1:kk),i_flux(1:kk))*1e6;
end
%i_flux_tot = i_flux_tot-i_flux_tot(3);
rho_ice=920; h = mean(cat(1,Floe.h));
%plot(t,(A_flux-A_flux(520))/1e6,'linewidth',2); hold on
%plot(t2,(A_flux2-A_flux2(520))/1e6,'linewidth',2); hold on
plot(t3,(A_flux3-A_flux3(520))/1e6,'linewidth',2); hold on
% plot(t4,A_flux4/1e6,'linewidth',2);
%plot(T_flux-T_flux(1),i_flux_tot/1e6,'linewidth',2)
plot(T_flux-T_flux(1),i_flux_tot2/1e6-300,'linewidth',2)
%legend('large','medium','small','Observations','fontsize',16)
legend('SubZero','Observations','fontsize',18)
%legend('Ocean V = 0.4 m/s','Ocean V = 0.3 m/s','Observations','fontsize',16)
%legend('A_{min} = 10 km^2','A_{min} = 1 km^2','Observations','fontsize',16)
legend('boxoff')
set(gca,'fontsize',16);
xlim([0 t3(end)])
ylim([0 9000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Sea Ice Area Transported (km$^2$)','fontsize',20,'interpreter','latex')
fig = figure(1);
exportgraphics(fig,['AreaFlux.jpg']);

%%
close all
load(['./Floe0000244.mat'],'Floe','Nb');
FloeL = [];
keep = zeros(1,length(Floe));
% for ii = 1+Nb:length(Floe)
%     if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-3.2e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.7e5 && min(Floe(ii).c_alpha(1,:))+Floe(ii).Xi>-5.5e4 && max(Floe(ii).c_alpha(1,:))+Floe(ii).Xi<4.5e4
%         FloeL = [FloeL Floe(ii)];
%         keep(ii) = 1;
%     end
% end
for ii = 1+Nb:length(Floe)
    if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-2.5e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-0.5e5 %&& min(Floe(ii).c_alpha(1,:))+Floe(ii).Xi>-5.5e4 && max(Floe(ii).c_alpha(1,:))+Floe(ii).Xi<4.5e4
        FloeL = [FloeL Floe(ii)];
        keep(ii) = 1;
    end
end
%create boundary polyshape
keep = logical(keep);
FloeOut = Floe(~keep);
clear poly
for ii =1:length(FloeOut)
    poly(ii) = polyshape(FloeOut(ii).c_alpha'+[FloeOut(ii).Xi FloeOut(ii).Yi]);
end
y_low = [-2.5e5 0.5e5 0.5e5 -2.5e5];
x_low = [-1e5 -1e5 1e5 1e5];
% y_low = [-1.35e5 -0.5e5 -1.35e5 -2e5 -1.35e5]-1.2e5;
% x_low = [-5e4 0 5e4 0 -5e4]-0.5e4;
lower_box = polyshape([x_low;y_low]');

for ii = 1:length(poly)
    lower_box = subtract(lower_box,poly(ii));
end
lower_box = rmholes(lower_box);
%A_upper = area(upper_box); A_lower = area(lower_box);

FloeLp = FloeL; clear FloeL; count = 1;
for ii = 1:length(FloeLp)
    [in,~] = inpolygon(FloeLp(ii).c_alpha(1,:)'+FloeLp(ii).Xi,FloeLp(ii).c_alpha(2,:)'+FloeLp(ii).Yi,x_low, y_low);
    if sum(in)/length(in) == 1
        FloeL(count) = FloeLp(ii);
        count = count+1;
    end
end

clear polyL
for ii =1:length(FloeL)
    polyL(ii) = polyshape(FloeL(ii).c_alpha'+[FloeL(ii).Xi FloeL(ii).Yi]);
end

edges = logspace( -1 , 1, 31 );
bins = (edges(2:end)+edges(1:end-1))/2;

Areas3 = cat(1,FloeL.area); %Find areas of segmented floes
A_lower = sum(Areas3);
a3 = sqrt(cat(1,Areas3));
hFSD3 = histogram(a3/1e3,edges);
edges3 = hFSD3.BinEdges;
val3 = hFSD3.Values;
clear FSDsmall
clear FSDsmall2
count3 = 1;
%Loop through to find floe sizes per km^2
for ii = 1:length(val3)
    FSDsmall(count3) = sum(val3(ii:end))/(A_lower)*1e6;
    % FSDsmall2(count3) = sum(val3(ii:end));
    count3 = count3+1;
end
save(['./FSDsmall.mat'],'FSDsmall');
%% Plot FSD
% load('./FSD10kmeanSmall.mat','FSDmean','bins'); FSDsmall = FSDmean;
load('./FSDmeanIndependent.mat','FSDmean'); FSDmedium = FSDmean;
load('./FSDmeanLarge.mat','FSDmean'); FSDlarge = FSDmean;
load('FSDaltSmall.mat','FSDaltSmall','bins'); FSDsmall = FSDaltSmall;
% load('./FSDmeanMediumEnd.mat','FSDmeanMedium'); FSDmedium = FSDmeanMedium;
%load('./FSDaltLarge.mat','FSDaltLarge'); FSDlarge = FSDaltLarge;

close all

hold on
% fig(1) = loglog(bins(25:end),FSDlarge(25:end),'linewidth',2);
%fig(2) = loglog(bins(18:end),FSDmedium(18:end),'linewidth',2);
%fig(1) = loglog(bins(23:end),FSDlarge(23:end)/2,'linewidth',2);
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')

binsUpper = bins(bins>0); slopes1 = -2.2;
load('./Modis/FSDobs.mat','FSDmean','FSDerror','bins')
%errorbar(bins,FSDmean,FSDerror,'linewidth',1.5)
%load('./FSDsentinel_10km.mat','FSDmeanSentinel','FSDerrorSentinel','bins')
load('./FSDsentinelLarge.mat','FSDmeanSentinel','FSDerrorSentinel','bins')
errorbar(bins,FSDmeanSentinel,FSDerrorSentinel,'b','linewidth',1.5)
fig(2) = loglog(bins(16:end),FSDmedium(16:end),'linewidth',3);
fig(3) = loglog(bins(16:end),FSDsmall(16:end),'r','linewidth',3);
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
fig(4) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
xlim([10.^-1 10])
ylim([9*10.^-5 20])
set(gca,'fontsize',18);
xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
%legend('Size Independent','Size Dependent','slope=-2','Sentinel-2', 'fontsize',16)
legend('Observations','SubZero:  \beta = 0','SubZero:  \beta = -1/4','fontsize',18)
%legend('A_{min} = 10 km^2','A_{min} = 1 km^2','slope=-2','Sentinel-2', 'fontsize',16)
legend('boxoff')
box on
fig = figure(1);
exportgraphics(fig,['FSDs.jpg']);
%% Plot FSD
 load('./FSDI10.mat','FSD','bins'); FSDI = FSD;
 load('./FSDNI10.mat','FSD'); FSDNI = FSD;

close all

hold on
fig(1) = loglog(bins(18:end),FSDI(18:end),'linewidth',2);
fig(2) = loglog(bins(18:end),FSDNI(18:end),'linewidth',2);
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')

binsUpper = bins(bins>0); slopes1 = -2;
fig(3) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
load('./Modis/FSDobs.mat','FSDmean','FSDerror','bins')
%errorbar(bins,FSDmean,FSDerror,'linewidth',1.5)
load('./FSDsentinelLarge.mat','FSDmeanSentinel','FSDerrorSentinel','bins')
errorbar(bins,FSDmeanSentinel,FSDerrorSentinel,'linewidth',1.5)
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
xlim([10.^-1 10])
ylim([10.^-3 10])
set(gca,'fontsize',18);
xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
legend('Islands','No Islands','slope=-2','Sentinel-2', 'fontsize',16)
legend('boxoff')
box on
fig = figure(1);
exportgraphics(fig,['FSDislands.jpg']);
%% 
FloeI = Floe(1:4); Floe2 = Floe(5:end);
Floe = [Floe2 FloeI]; Nb = Nb - 4;

close all
clear poly
for ii =1:length(Floe)
    poly(ii) = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end
figure
plot(poly)

%% 
load('transport_offset.mat','transport_off');
for jj = 100:length(Floe)
    load(['./Floes/Floe' num2str(jj,'%07.f') '.mat'])
    A_total_flux = A_total_flux-transport_off.area;
    M_total_flux = M_total_flux-transport_off.mass;
end

for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-320000
        Floe(ii).Fx = 4;
    elseif max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<0 && Floe(ii).Fx < 2 % && min(Floe(ii).c_alpha(1,:))+Floe(ii).Xi<min(c2_boundary(1,:))
        Floe(ii).Fx = 2;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<0 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>0 && Floe(ii).Fx < 2
        Floe(ii).Fx = 1;
    end
end
Fx = cat(1,Floe.Fx);
length(poly(Fx==4))
figure
plot(poly(Fx==4))
%%
%Plot FSD
%load('./FSDmeanAlt.mat','FSDmeanAlt'); FSDalt = FSDmeanAlt;% alpha = 1/2
load('./FSDmeanAlt2.mat','FSDmeanAlt2'); FSDalt2 = FSDmeanAlt2;% alpha = 1/4
%load('./FSDmeanMediumEarlier.mat','FSDmeanMediumEarlier','bins'); FSDmedium = FSDmeanMediumEarlier;
%load('./FSDmeanMediumEnd.mat','FSDmeanMedium','bins'); FSDmedium = FSDmeanMedium;

close all

hold on
% fig(1) = loglog(bins(25:end),FSDlarge(25:end),'linewidth',2);
% fig(2) = loglog(bins(18:end),FSDmedium(18:end),'linewidth',2);
%fig(1) = loglog(bins(16:end),FSDalt(16:end),'linewidth',2);
fig(2) = loglog(bins(16:end),FSDalt2(16:end),'linewidth',2);
%fig(3) = loglog(bins(16:end),FSDmedium(16:end),'linewidth',2);
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
binsUpper = bins(bins>0); slopes1 = -2;
fig(3) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
load('./Modis/FSDobs.mat','FSDmean','FSDerror','bins')
%errorbar(bins,FSDmean,FSDerror,'linewidth',1.5)
load('./FSDsentinelLarge.mat','FSDmeanSentinel','FSDerrorSentinel','bins')
errorbar(bins,FSDmeanSentinel,FSDerrorSentinel,'r','linewidth',1.5)
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
xlim([1 10])
ylim([10.^-3 1])
set(gca,'fontsize',18);
xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
legend('alpha = 1/4','slope=-2','Sentinel-2', 'fontsize',16)
%legend('alpha = 1/2','alpha = 1/4','alpha = 0','slope=-2','Sentinel-2', 'fontsize',16)
legend('boxoff')
box on
fig = figure(1);
exportgraphics(fig,['FSDalt.jpg']);
%% Find slope values for different fracture rules
% close all
% load('./FSDmeanAlt.mat','FSDmeanAlt'); FSDalt = FSDmeanAlt;% alpha = 1/2
% load('./FSDmeanAlt2.mat','FSDmeanAlt2'); FSDalt2 = FSDmeanAlt2;% alpha = 1/4
% %load('./FSDmeanAlt.mat','FSDmean','bins'); FSDalt = FSDmean;
% load('./FSDmeanMediumEarlier.mat','FSDmeanMedium','bins'); FSDmedium = FSDmeanMedium;
% x1 = log10(bins); y1 = log10(FSDmeanMedium);
% plot(x1,y1)
% x1 = x1(16:28);y1 = y1(16:28);
% f = fit(x1',y1','poly1'); 
% m1 = f.p1;
% 
% x1 = log10(bins); y1 = log10(FSDmeanAlt2);
% plot(x1,y1)
% x1 = x1(16:28);y1 = y1(16:28);
% f = fit(x1',y1','poly1'); 
% m2 = f.p1;
% 
% x1 = log10(bins); y1 = log10(FSDmeanAlt);
% plot(x1,y1)
% x1 = x1(16:25);y1 = y1(16:25);
% f = fit(x1',y1','poly1'); 
% m3 = f.p1;

load('slopes_independent.mat','m'); msmall = m;
load('m_small.mat','m')
close all
dt = 5; nDTOut = 350;
t = (0:492)*dt*nDTOut/24/3600;
plot(t,msmall,'linewidth',2)
hold on
plot(t,m,'linewidth',2)
set(gca,'fontsize',18);
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Exponent of Power Law','fontsize',20,'interpreter','latex')

t_val = 1.895; slopes = [-1.7 -2.8 -2 -1.75 -2.6 -2.5 -2.2];
FSDstd = std(slopes);
FSDerror = t_val*FSDstd/sqrt(7);
FSDmean = mean(slopes);


% alph_vals = [0 1/4 1/2]; m_vals = [m1 m2 m3];
% plot(alph_vals,m_vals,'rx-','linewidth',2)
plot(t,FSDmean*ones(length(t)),'k--')
plot(t,(FSDmean+FSDerror)*ones(length(t)),'k')
plot(t,(FSDmean-FSDerror)*ones(length(t)),'k')
% set(gca,'fontsize',18);
% xlabel('Fracture Rule Exponent','fontsize',20,'interpreter','latex')
% ylabel({'FSD Power Law Slope Value'},'fontsize',20,'interpreter','latex')
box on
% fig = figure(1);
% exportgraphics(fig,['FSDaltSlopes.jpg']);

legend('SubZero:  \beta = 0','SubZero:  \beta = -1/4','fontsize',24)
legend('boxoff')
fig = figure(1)
exportgraphics(fig,['ExponentEvolution.jpg'] ,'resolution',300);
%% 
%load('WindsMomentumBudget.mat','dpdt','Ocn','Atm','coast','islands','dpdt2','Ocn2','Atm2','coast2','islands2')
%load('MomentumBudget10Alt.mat','dpdt','Ocn','Atm','coast','islands','dpdt2','Ocn2','Atm2','coast2','islands2')
load('MomentumBudget10.mat','dpdt','Ocn','Atm','coast','islands','dpdt2','Ocn2','Atm2','coast2','islands2')

island = sum(islands,1);
island2 = sum(islands2,1);


%dpdt = Ocn + Atm + coast + island;
%dpdt2 = Ocn2 + Atm2 + coast2 + island2;

residual = dpdt+Ocn + Atm + coast + island;
residual2 = dpdt2+ Ocn2 + Atm2 + coast2 + island2;

close all
%x = ["dpdt"; "Atm"; "Ocn"; "Islands"; "Coast"];
x = ["dpdt"; "Atm"; "Ocn"; "Islands"; "Coast"; "residual"];
%y = [mean(dpdt(1:end)) mean(dpdt2(1:end)); mean(Atm(1:end)) mean(Atm2(1:end)); mean(Ocn(1:end)) mean(Ocn2(1:end)); mean(island(1:end)) mean(island2(1:end)); mean(coast) mean(coast2(1:end))];
y = [mean(dpdt(300:end)) mean(dpdt2(300:end)); mean(Atm(300:end)) mean(Atm2(300:end)); mean(Ocn(300:end)) mean(Ocn2(300:end)); mean(island(300:end)) mean(island2(300:end)); mean(coast(300:end)) mean(coast2(300:end)); mean(residual(300:end)) mean(residual2(300:end))];
y = [y(:,2) y(:,1)];
bh = bar(x(2:end-1),y(2:end-1,:),'BarWidth', 1);
bh(1).FaceColor = 'black';
bh(2).FaceColor = [91, 207, 244] / 255;
lgd = legend('No Islands', 'islands');
fontsize(lgd,16,'points');
set(gca,'fontsize',16);
legend('box','off')
ylabel('Force (N)','fontsize',16)
box on
fig = figure(1);
exportgraphics(fig,['MomentumBudget.jpg']);
%%
load('MomentumBudget10.mat','dpdt','Ocn','Atm','coast','islands','dpdt2','Ocn2','Atm2','coast2','islands2')

island = sum(islands,1);
island2 = sum(islands2,1);


%dpdt = Ocn + Atm + coast + island;
%dpdt2 = Ocn2 + Atm2 + coast2 + island2;

residual = dpdt+Ocn + Atm + coast + island;
residual2 = dpdt2+ Ocn2 + Atm2 + coast2 + island2;

close all
%x = ["dpdt"; "Atm"; "Ocn"; "Islands"; "Coast"];
x = ["Atm+Ocn"; "Islands"; "Coast"];
%y = [mean(dpdt(1:end)) mean(dpdt2(1:end)); mean(Atm(1:end)) mean(Atm2(1:end)); mean(Ocn(1:end)) mean(Ocn2(1:end)); mean(island(1:end)) mean(island2(1:end)); mean(coast) mean(coast2(1:end))];
y = [mean(Atm(300:end))+mean(Ocn(300:end)) mean(Atm2(300:end))+mean(Ocn2(300:end)); mean(island(300:end)) mean(island2(300:end)); mean(coast(300:end)) mean(coast2(300:end))];
y = [y(:,2) y(:,1)];
bh = bar(x,y,'BarWidth', 1);
bh(1).FaceColor = 'black';
bh(2).FaceColor = [91, 207, 244] / 255;
lgd = legend('No Islands', 'islands');
fontsize(lgd,16,'points');
set(gca,'fontsize',16);
legend('box','off')
ylabel('Force (N)','fontsize',16)
box on
fig = figure(1);
exportgraphics(fig,['MomentumBudget3.jpg']);
%% break down forces per island
load('WindsMomentumBudget.mat','dpdt','Ocn','Atm','coast','islands','time')

close all
% figure
islands(islands<0)=0;
% plot(time/24/3600,islands(1,:),'linewidth',2)
% hold on
% plot(time/24/3600,islands(2,:),'linewidth',2)
% plot(time/24/3600,islands(3,:),'linewidth',2)
% plot(time/24/3600,islands(4,:),'linewidth',2)
% ylabel('Force (N)','fontsize',20)
% xlabel('Time (days)','fontsize',20)
% set(gca,'fontsize',18);
% lgd = legend('box','off');
% fontsize(lgd,22,'points');
% ylim([0 6e8])
% box on
% legend('Hans','Hannah', 'Crozier', 'Franklin')
% fig = figure(1);
% exportgraphics(fig,['IslandBreakdown.jpg']);

x = time/24/3600;
Y = [islands(1,:); islands(1,:)+islands(2,:); islands(1,:)+islands(2,:)+islands(3,:); islands(1,:)+islands(2,:)+islands(3,:)+islands(4,:)];
area(x,Y')
ylabel('Force (N)','fontsize',20)
xlabel('Time (days)','fontsize',20)
set(gca,'fontsize',24);
lgd = legend({'Hans','Hannah', 'Crozier', 'Franklin'});
lgd = legend('box','off');
fontsize(lgd,24,'points');
xlim([0 5])
box on
fig = figure(1)
exportgraphics(fig,['IslandBreakdown.jpg']);
%%
close all
ratio=1/1.5;
fig=figure('Position',[100 100 500 500*ratio],'visible','on');
set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
figure(fig)
clf(fig); hold on
clear poly
for i=1:length(floes)
    poly = polyshape(floes(i).c_alpha'+[floes(i).Xi floes(i).Yi]);
    plot(poly,'FaceColor',[1 0 0]*floes(i).h,'EdgeColor',[1 1 1]*0.2);
%     plot(poly,'FaceColor',[1 1 1]*Floes(i).h,'FaceAlpha',0.5);%(1+h(j)*(n-1))/n);
end

map = zeros(101,3);
map(:,1) = 0:0.01:1;
colormap(map)
cb = colorbar;
cb.Label.String = 'Thickness';
cb.Label.FontSize = 16;
caxis([0 1]);
annotation('textbox',...
    cb.Position,...
    'FitBoxToText','off',...
    'FaceAlpha',0.5,...
    'EdgeColor',[1 1 1],...
    'BackgroundColor',[1 1 1]);
fig = figure(1);
xlim([-1.5e4 1.5e4])
ylim([-1e4 1e4])
%% 
close all
% figure
load('./FloesMedium.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
A_flux = A_total_flux_L+A_flux_L_tmp;
%A_flux = A_flux-A_flux(3458);
A_flux = A_flux-A_flux(2); A_flux(1) = 0;
t = t_flux/24/3600;

load('./FloesNoIslands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
A_flux2 = A_total_flux_L+A_flux_L_tmp;
%A_flux2 = A_flux2-A_flux2(3458); 
A_flux2 = A_flux2-A_flux2(3); A_flux2(1) = 0;A_flux2(2) = 0;
t2 = t_flux/24/3600;


rho_ice=920; h = mean(cat(1,Floe.h));
plot(t,(A_flux-A_flux(520))/1e6,'linewidth',2); hold on
plot(t2,(A_flux2-A_flux2(520))/1e6,'linewidth',2);
legend('Islands','No Islands','fontsize',16)
legend('boxoff')
set(gca,'fontsize',18);
xlim([2 t(end)])
ylim([0 6000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Transport (km$^2$)','fontsize',20,'interpreter','latex')

fig = figure(1);
exportgraphics(fig,['AreaFluxIslandsComp.jpg']);
%% Idealized winds compare
close all
% figure
%load('./Floe0000166.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
load('./I15.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux = A_total_flux_L+A_flux_L_tmp;
A_flux = A_flux-A_flux(2); A_flux(1) = 0;
t = t_flux/24/3600;

%load('./Floe0000156.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
load('./NI15.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux2 = A_total_flux_L+A_flux_L_tmp;
A_flux2 = A_flux2-A_flux2(2); A_flux2(1) = 0;
t2 = t_flux/24/3600;


rho_ice=920; h = mean(cat(1,Floe.h));
plot(t,(A_flux-A_flux(520))/1e6,'linewidth',2); hold on
plot(t2,(A_flux2-A_flux2(520))/1e6,'linewidth',2);
legend('Islands','No Islands','fontsize',16)
legend('boxoff')
set(gca,'fontsize',18);
xlim([1 t(end)])
ylim([0 5000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Transport (km$^2$)','fontsize',20,'interpreter','latex')
box on
fig = figure(1);
%exportgraphics(fig,['AreaFluxIdealizedComp.jpg']);
%%

close all
% figure
load('./large_slow.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
A_flux = A_total_flux+A_flux_tmp;
%A_flux = A_flux-A_flux(3); A_flux(1) = 0;A_flux(2) = 0;
A_flux = A_flux-A_flux(2); A_flux(1) = 0;
t = t_flux/24/3600;
% load('./Floe0000240.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
% A_flux_new = A_total_flux+A_f[lux_tmp;
% A_flux_new = A_flux_new-A_flux_new(3); A_flux(1) = 0;
% t_new = t_flux/24/3600;
% A_flux = [A_flux A_flux_new(3:end)+A_flux(end)];
% t = [t t_new(3:end)];
load('./Floe0000274.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux2 = A_total_flux+A_flux_tmp;
%A_flux2 = A_flux2-A_flux2(3458); 
A_flux2 = A_flux2-A_flux2(3); A_flux2(1) = 0;A_flux2(2) = 0;
t2 = t_flux/24/3600;
load('./large.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux3 = A_total_flux+A_flux_tmp;
%A_flux2 = A_flux2-A_flux2(3458); 
A_flux3 = A_flux3-A_flux3(3); A_flux3(1) = 0;A_flux3(2) = 0;
t3 = t_flux/24/3600;

i_flux_tot = 0; i_flux_tot2 = 0;
for kk = 2:length(i_flux)
    i_flux_tot(kk) = i_flux_tot(kk-1)+i_flux(kk)*(T_flux(kk)-T_flux(kk-1))*1e6;
    i_flux_tot2(kk) = trapz(T_flux(1:kk),i_flux(1:kk))*1e6;
end
%i_flux_tot = i_flux_tot-i_flux_tot(3);
rho_ice=920; h = mean(cat(1,Floe.h));
plot(t,(A_flux-A_flux(750))/1e6,'linewidth',2); hold on
% plot(t2,(A_flux2-A_flux2(520))/1e6,'linewidth',2);
plot(t2,(A_flux2-A_flux2(750))/1e6,'linewidth',2);
% plot(t3,(A_flux3-A_flux3(750))/1e6,'linewidth',2);
%plot(T_flux-T_flux(1),i_flux_tot/1e6,'linewidth',2)
plot(T_flux-T_flux(1),i_flux_tot2/1e6,'linewidth',2)
legend('large','small','Observations','fontsize',16)
legend('boxoff')
set(gca,'fontsize',18);
xlim([0 10])
ylim([0 12000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Transport (km$^2$)','fontsize',20,'interpreter','latex')
fig = figure(1);

%%
close all
close all
T = readtable('NaresStrait_iaf_20160901-20190831.csv');
Maydata = T(303:342,:); ice_flux = Maydata(:,10); iceflux_m = table2array(ice_flux); 
Julydata = T(797:824,:); ice_flux = Julydata(:,10); iceflux_j = table2array(ice_flux); 
i_flux = [iceflux_m];%; iceflux_j];
clear Time;

bins = 0:250:3000;
load('./Floe0000493.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux = A_total_flux+A_flux_tmp;
A_flux = A_flux-A_flux(3); A_flux(1) = 0;A_flux(2) = 0;
load('./FloeSmall0_4.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux2 = A_total_flux+A_flux_tmp;
A_flux2 = A_flux2-A_flux2(3); A_flux2(1) = 0;A_flux2(2) = 0;
t = t_flux/24/3600;
tvals = 6900:100:length(t);
Transport1 = A_flux(tvals)/1e6; tdif = t(tvals(2))-t(tvals(1)); T1diff = Transport1(2:end)-Transport1(1:end-1); flux1 =T1diff/tdif;
Transport2 = A_flux2(tvals)/1e6; tdif = t(tvals(2))-t(1); T2diff = Transport2(2:end)-Transport2(1:end-1); flux2 =T2diff/tdif;
h = histogram(flux1,bins);
p1 = histcounts(flux1,bins,'Normalization','pdf');
hold on
p2 = histcounts(flux2,bins,'Normalization','pdf');
p3 = histcounts(i_flux,bins,'Normalization','pdf');
% plot it
figure
binCenters = h.BinEdges + (h.BinWidth/2);
plot(binCenters(1:end-1), p1, 'linewidth', 2); hold on
%plot(binCenters(1:end-1), p2, 'linewidth', 2)
plot(binCenters(1:end-1), p3, 'linewidth', 2)
% histogram(flux1)
% hold on
% histogram(flux2)
% histogram(i_flux(1:12))
%legend('Ocean V = 0.4 m/s','Ocean V = 0.3 m/s','Observations','fontsize',20)
legend('SubZero','Observations','fontsize',20)
legend('boxoff')
set(gca,'fontsize',18);
xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
ylabel('Probability Density','fontsize',20,'interpreter','latex')
box on
fig = figure(2);
exportgraphics(fig,['FluxPDF.jpg']);
%%
close all
% figure
load('Floe5NoIslands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux = A_total_flux_L+A_flux_L_tmp;
t = t_flux/24/3600;

load('Floe5Islands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux2 = A_total_flux_L+A_flux_L_tmp;
t2 = t_flux/24/3600;

load('Floe10NoIslands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux3 = A_total_flux_L+A_flux_L_tmp;
t3 = t_flux/24/3600;

load('Floe10Islands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux4 = A_total_flux_L+A_flux_L_tmp;
t4 = t_flux/24/3600;

load('Floe15NoIslands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux5 = A_total_flux_L+A_flux_L_tmp;
t5 = t_flux/24/3600;

load('Floe15Islands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux6 = A_total_flux_L+A_flux_L_tmp;
t6 = t_flux/24/3600;

rho_ice=920; h = mean(cat(1,Floe.h));
% plot(t,A_flux/1e6,'linewidth',2); hold on
% plot(t2,A_flux2/1e6,'linewidth',2);
% plot(t3,A_flux3/1e6,'linewidth',2);
% plot(t4,A_flux4/1e6,'linewidth',2);
plot(t5,A_flux5/1e6,'linewidth',2);hold on;
plot(t6,A_flux6/1e6,'linewidth',2);
legend
% legend('Islands','No Islands','fontsize',16)
% legend('boxoff')
set(gca,'fontsize',18);
%xlim([1 5])
%ylim([0 6000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Transport (km$^2$)','fontsize',20,'interpreter','latex')
%%
close all
% figure
load('Floe0000031.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux = A_total_flux_L+A_flux_L_tmp;
t = t_flux/24/3600;

load('Floe0000032.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
A_flux2 = A_total_flux_L+A_flux_L_tmp;
t2 = t_flux/24/3600;

rho_ice=920; h = mean(cat(1,Floe.h));
plot(t,A_flux/1e6,'linewidth',2); hold on
plot(t2,A_flux2/1e6,'linewidth',2);
legend
legend('No Islands','Islands','fontsize',16)
% legend('boxoff')
set(gca,'fontsize',18);
%xlim([2 t(end)])
%ylim([0 6000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Transport (km$^2$)','fontsize',20,'interpreter','latex')
%%
% load('Floe5NoIslands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
% A_flux = A_total_flux_L+A_flux_L_tmp;
% t = t_flux/24/3600;
% 
% load('Floe5Islands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
% A_flux2 = A_total_flux_L+A_flux_L_tmp;
% t2 = t_flux/24/3600;

% load('Floe10NoIslands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
% A_flux3 = A_total_flux_L+A_flux_L_tmp;
load('transportNI.mat','transport','time');
A_flux3 = transport;
t3 = t_flux/24/3600;

% load('Floe10Islands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
% A_flux4 = A_total_flux_L+A_flux_L_tmp;
load('transportI.mat','transport','time');
A_flux4 = transport;
t4 = t_flux/24/3600;

% load('Floe15NoIslands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
% A_flux5 = A_total_flux_L+A_flux_L_tmp;
load('transportNI15.mat','transport','time');
A_flux5 = transport;
t5 = t_flux/24/3600;

% load('Floe15Islands.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp')
% A_flux6 = A_total_flux_L+A_flux_L_tmp;
load('transportI15.mat','transport','time');
A_flux6 = transport;
t6 = t_flux/24/3600;

close all
% x = ["5 m/s"; "10 m/s"; "15 m/s"];
% y = [A_flux(end) A_flux2(end); A_flux3(end) A_flux4(end); A_flux5(end) A_flux6(end)]/1e6;
x = ["10 m/s"; "15 m/s"];
y = [A_flux3(end) A_flux4(end); A_flux5(end) A_flux6(end)]/1e6;
bh = bar(x,y);
bh(1).FaceColor = 'black';
bh(2).FaceColor = 'cyan';
%subplot(1,2,2)
%x = ["dpdt" "Atm" "Ocn" "Islands" "Coast"];
%y = [mean(dpdt2(150:end)) mean(Atm2(150:end)) mean(Ocn2(150:end)) mean(island2(150:end)) mean(coast2(150:end))];
%bar(x,y)
lgd = legend('no islands','islands');
fontsize(lgd,18,'points');
set(gca,'fontsize',18);
legend('box','off')
ylabel('Area Transport (km^2)','fontsize',20)
xlabel('Wind Speed (m/s)','fontsize',20)
fig = figure(1);
exportgraphics(fig,['AreaFluxCompare.jpg']);
%%
bins = 5e7:1e7:2.5e8;
h = histogram(data,bins);
p1 = histcounts(data,bins,'Normalization','pdf');
%%
close all
addpath('/Users/bmontemuro/Downloads/nares_15_islands/Initialize_Model')
addpath('/Users/bmontemuro/Downloads/nares_15_islands/Nares')
c2_boundary=initialize_boundaries_Nares();
ymin = min(c2_boundary(2,:));
y_low = [-1.8e5 ymin ymin -1.8e5];
x_low = [-1e5 -1e5 1e5 1e5];
lower_box = polyshape([x_low;y_low]');

load('NaresNoIslands0.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
T0ni = Areas;

load('NaresIslands0.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
T0i = Areas;

load('Nares5islands.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
transport5islands = Areas-T0i;

load('Nares5NoIslands.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
transport5noislands = Areas-T0ni;

load('Nares10islands.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
transport10islands = Areas-T0i;

load('Nares10NoIslands.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
transport10noislands = Areas-T0ni;

load('Nares15islands.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
transport15islands = Areas-T0i;

load('Nares15NoIslands.mat','Floe','Nb');
Areas = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        Areas = Areas + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        Areas = Areas + Anow;
    end
end
transport15noislands = Areas-T0ni;

x = ["5 m/s"; "10 m/s"; "15 m/s"];
y = [transport5noislands transport5islands; transport10noislands transport10islands; transport15noislands transport15islands]/1e6;
bh = bar(x,y);
bh(1).FaceColor = 'black';
bh(2).FaceColor = [91, 207, 244] / 255;
%subplot(1,2,2)
%x = ["dpdt" "Atm" "Ocn" "Islands" "Coast"];
%y = [mean(dpdt2(150:end)) mean(Atm2(150:end)) mean(Ocn2(150:end)) mean(island2(150:end)) mean(coast2(150:end))];
%bar(x,y)
lgd = legend('No Islands','Islands');
fontsize(lgd,18,'points');
set(gca,'fontsize',18);
legend('box','off')
ylabel('Sea Ice Area Transported (km$^2$)','fontsize',20,'interpreter','latex')
xlabel('Wind Speed (m/s)','fontsize',20,'interpreter','latex')
fig = figure(1);
exportgraphics(fig,['AreaFluxCompare.jpg']);
%%
%Plot FSD
load('./FSDmeanMedium2.mat','FSDmean','bins'); FSDnoIs = FSDmean;
load('./FSDmeanMedium.mat','FSDmean'); FSDmedium = FSDmean;

close all
figure;
hold on
fig(1) = loglog(bins(18:end),FSDnoIs(18:end),'linewidth',2);
fig(2) = loglog(bins(18:end),FSDmedium(18:end),'linewidth',2);
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
binsUpper = bins(bins>0); slopes1 = -2;
fig(4) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
load('./Modis/FSDobs.mat','FSDmean','FSDerror','bins')
errorbar(bins,FSDmean,FSDerror,'linewidth',1.5)
load('./FSDsentinel.mat','FSDmeanSentinel','FSDerrorSentinel','bins')
errorbar(bins,FSDmeanSentinel,FSDerrorSentinel,'linewidth',1.5)
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
xlim([5*10.^-1 10])
ylim([10.^-3 1])
legend('No Islands','Islands','small','slope=-2','Terra','Landsat-8', 'fontsize',16)
legend('boxoff')
fig = figure(1);
%exportgraphics(fig,['FSDislands.jpg']);
%% Find obs mean slope and confidence intervals

t_val = 1.895; slopes = [-1.7 -2.8 -2 -1.75 -2.6 -2.5 -2.2];
FSDstd = std(slopes);
FSDerror = t_val*FSDstd/sqrt(7);
FSDmean = mean(slopes)
%%
for jj = 1:200
    load(['Floe' num2str(jj,'%07.f') '.mat'])
    fill = 0;
       for ii = 1+Nb:length(Floe)
           if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>1.17e5 
               fill = fill + 1;
           end
       end
       if fill == 0
           jj
           error()
       end
end

%% 
% mkdir figs
for ii = 1:200
    load(['./winds15NoIslands/Floe' num2str(ii,'%07.f') '.mat'])
    %load('FloeStartI.mat','Floe','Nb'); 
    clear poly;
    for i = 1:length(Floe); poly(i) = polyshape(Floe(i).c_alpha'+[Floe(i).Xi Floe(i).Yi]);end
    close all; 
    ratio = 2; fig = 0;
    if (fig==0 || ~isvalid(fig))
        fig=figure('Position',[10 10 200 200*ratio],'visible','on');
        set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
    end
    figure(fig)
    clf(fig);
    hold on
    set(gca,'Color',[0.5843    0.8157    0.9882])
    h = cat(1,Floe.h);hmax = 4.5;
    h(h>3)=3;
    for i = Nb+1:length(Floe)
         plot(poly(i),'FaceColor',[1 1 1]*h(i)/hmax,'FaceAlpha',1,'EdgeColor','w');
%         plot(poly(i),'FaceColor',[1 1 1]*h(i)/hmax,'FaceAlpha',1,'EdgeAlpha',0);
    end
    if Nb > 0
        plot(poly(1:Nb),'FaceColor',[0 0.2 0],'FaceAlpha',1,'EdgeAlpha',0);
    end
    xlim([-1e5 1e5])
    ylim([-3e5 1e5])
    fig = figure(1);
    exportgraphics(fig,['./figs/' num2str(ii,'%03.f') '.jpg'] ,'resolution',300);
%    exportgraphics(fig,['./figs/full' num2str(ii,'%03.f') '.jpg'] ,'resolution',300);
end 

%% 
dt = 5; nDTOut = 350;
clear A; clear A2
clear Time; clear Time2
dissolved = 0; A_kane = [];
for ii = 1:673
    load(['./nares_medium/Floes/Floe' num2str(ii,'%07.f') '.mat'],'Floe','Nb');
    i_step = (ii-1)*nDTOut;
    Time(ii) = i_step*dt;
    areas = cat(1,Floe.area);
    keep = logical(zeros(1,length(Floe)));
    for jj = 1+Nb:length(Floe)
        if max(Floe(jj).c_alpha(2,:))+Floe(jj).Yi<-3e5  
            keep(jj) = 1;
        end
    end
    Anow = areas(keep); %x = Xi(keep); y = Yi(keep);
    keep2 = logical(zeros(1,length(A_kane)));
    for jj = 1:length(keep2)
       I = find(abs((Anow - A_kane(jj))/A_kane(jj))<0.01);
       if ~isempty(I)
           keep2(jj) = 1;
       end
    end
    if sum(~keep2)>0
        dissolved = dissolved+sum(A_kane(~keep2));
    end
    A(ii) = sum(Anow)+dissolved;
    A_kane = Anow; %xkane = x; ykane = y;
end
dissolved = 0; A_kane = [];
for ii = 1:448
    load(['./nares_med_no_islands/Floes/Floe' num2str(ii,'%07.f') '.mat'],'Floe','Nb');
    i_step = (ii-1)*nDTOut;
    Time2(ii) = i_step*dt;
    areas = cat(1,Floe.area);
    keep = logical(zeros(1,length(Floe)));
    for jj = 1+Nb:length(Floe)
        if max(Floe(jj).c_alpha(2,:))+Floe(jj).Yi<-3e5  % && min(floe.c_alpha(1,:))+floe.Xi<min(c2_boundary(1,:))
            keep(jj) = 1;
        end
    end
    Anow = areas(keep); %x = Xi(keep); y = Yi(keep);
    keep2 = logical(zeros(1,length(A_kane)));
    for jj = 1:length(keep2)
       I = find(abs((Anow - A_kane(jj))/A_kane(jj))<0.01);
       if ~isempty(I)
           keep2(jj) = 1;
       end
    end
    if sum(~keep2)>0
        dissolved = dissolved+sum(A_kane(~keep2));
    end
    A2(ii) = sum(Anow)+dissolved;
    A_kane = Anow; %xkane = x; ykane = y;
end
save('transport.mat','Time','A','Time2','A2')
plot(Time/24/3600,A/1e6,'linewidth',2) 
hold on
plot(Time2/24/3600,A2/1e6,'linewidth',2)
legend('islands','no islands','fontsize',16)
legend('boxoff')
set(gca,'fontsize',18);
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Transport (km$^2$)','fontsize',20,'interpreter','latex')
fig = figure(1);
%exportgraphics(fig,['FluxLower.jpg'] ,'resolution',300);

%%
edges = logspace( -1 , 1, 31 );
bins = (edges(2:end)+edges(1:end-1))/2;
x1 = log10(bins); x1 = x1(15:26);
clear m
for ii = 1:493
    load(['./FloesPaperNew/FSD' num2str(ii,'%07.f') '.mat'],'FSD');
    y1 = log10(FSD);
    y1 = y1(15:26);
    f = fit(x1',y1','poly1');
    m(ii) = f.p1;
end
save('slopes.mat','m')
%%
load('slopes_independent.mat','m'); msmall = m;
load('m_small.mat','m')
close all
dt = 5; nDTOut = 350;
t = (0:492)*dt*nDTOut/24/3600;
plot(t,msmall,'linewidth',2)
hold on
plot(t,m,'linewidth',2)
legend('Size Independent','Size Dependent','fontsize',24)
legend('boxoff')
set(gca,'fontsize',18);
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Exponent of Power Law','fontsize',20,'interpreter','latex')
fig = figure(1)
exportgraphics(fig,['ExponentEvolution.jpg'] ,'resolution',300);
%%
close all
ratio=0.5;%max(ocean.Yo)/max(ocean.Xo);
fig = 0;
if (fig==0 || ~isvalid(fig))
    fig=figure('Position',[10 10 1000 1000*ratio],'visible','on');  
    set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
end
figure(fig)
clf(fig); hold on

options.handle     = figure(1);
options.color_area1 = [128 193 219]./255;    % Blue theme
options.color_line1 = [ 52 148 186]./255;
options.color_area2 = [243 169 114]./255;    % Orange theme
options.color_line2 = [236 112  22]./255;
options.alpha      = 0.5;
options.line_width = 2;

load('FSDobsSlopes.mat','dFSDmean','dFSDerror','dbins')
toss = logical(dFSDmean==0); dbins(toss) = []; dFSDmean(toss) = []; dFSDerror(toss) = [];
x_vector1 = [dbins, fliplr(dbins)]; y_vector1=[dFSDmean+dFSDerror,fliplr(dFSDmean-dFSDerror)];
% y_vector1(y_vector1<1e-15) = 1e-15;
plot(dbins, dFSDmean, 'color', options.color_line1,'LineWidth', options.line_width);


load('FSDsentinelSlopes.mat','dFSDmeanSentinel','dFSDerrorSentinel','dbins')
toss = logical(dFSDmeanSentinel==0); dbins(toss) = []; dFSDmeanSentinel(toss) = []; dFSDerrorSentinel(toss) = [];
%dbins = dbins(2:end); dFSDmeanLandsat = dFSDmeanLandsat(2:end); dFSDerrorLandsat = dFSDerrorLandsat(2:end);
x_vector = [dbins, fliplr(dbins)]; y_vector=[dFSDmeanSentinel+dFSDerrorSentinel,fliplr(dFSDmeanSentinel-dFSDerrorSentinel)];
% y_vector(y_vector<1e-15) = 1e-15;
plot(dbins, dFSDmeanSentinel, 'color', options.color_line2,'LineWidth', options.line_width);

% binsUpper = dbins(dbins>0); slopes1 = -2;
% fig(4) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
patch = fill(x_vector1, y_vector1, options.color_area1); 
hold on
set(patch, 'edgecolor', 'none');
set(patch, 'FaceAlpha', options.alpha); hold on
patch2 = fill(x_vector, y_vector, options.color_area2);
% errorbar(dbins,dFSDmeanLandsat,dFSDerrorLandsat)
set(patch2, 'edgecolor', 'none');
set(patch2, 'FaceAlpha', options.alpha); hold on

set(gca, 'xScale', 'log')
xlim([10.^-1 10])
ylim([-6 1])
set(gca,'fontsize',18);
xlabel('Floe Size (km)','fontsize',24,'interpreter','latex','fontname','arial')
ylabel({'FSD power law slope'},'fontsize',24,'interpreter','latex','fontname','arial')
figure(1)
legend('Terra','Sentinel-2', 'fontsize',20)
legend('boxoff')
box on
fig = figure(1);
exportgraphics(fig,['FSDobsSlopes.jpg']);
%%
close all
ratio=0.6;%max(ocean.Yo)/max(ocean.Xo);
fig = 0;
if (fig==0 || ~isvalid(fig))
    fig=figure('Position',[10 10 1000 1000*ratio],'visible','on');  
    set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
end
figure(fig)
clf(fig); hold on

options.handle     = figure(1);
options.color_area1 = [128 193 219]./255;    % Blue theme
options.color_line1 = [ 52 148 186]./255;
options.color_area2 = [243 169 114]./255;    % Orange theme
options.color_line2 = [236 112  22]./255;
options.alpha      = 0.5;
options.line_width = 2;
 
load('FSDobs.mat','FSDmean','FSDerror','bins')
% x_vector1 = [bins, fliplr(bins)]; y_vector1=[FSDmean+FSDerror,fliplr(FSDmean-FSDerror)];
%y_vector1(y_vector1<1e-10) = 1e-10;
x_vector1 = [bins, fliplr(bins)]; y_vector1=FSDmean+FSDerror; y_vector2 = FSDmean-FSDerror;
y_vector2(y_vector2<1e-10) = FSDmean(y_vector2<1e-10);
y_vector1=[y_vector1,fliplr(y_vector2)];
plot(bins, FSDmean, 'color', options.color_line1,'LineWidth', options.line_width);


%load('FSDsentinel.mat','FSDmeanSentinel','FSDerrorSentinel','bins')
load('FSDsentinelLarge.mat','FSDmeanSentinel','FSDerrorSentinel','bins')
FSDerrorSentinel(FSDmeanSentinel==0)=[]; bins(FSDmeanSentinel==0)=[]; FSDmeanSentinel(FSDmeanSentinel==0)=[];
% x_vector = [bins, fliplr(bins)]; y_vector=[FSDmeanSentinel+FSDerrorSentinel,fliplr(FSDmeanSentinel-FSDerrorSentinel)];
% y_vector(y_vector<1e-10) = 1e-10;
x_vector = [bins, fliplr(bins)]; y_vector=FSDmeanSentinel+FSDerrorSentinel; y_vector2 = FSDmeanSentinel-FSDerrorSentinel;
y_vector2(y_vector2<1e-10) = FSDmeanSentinel(y_vector2<1e-10);
y_vector=[y_vector,fliplr(y_vector2)];
plot(bins, FSDmeanSentinel, 'color', options.color_line2,'LineWidth', options.line_width);

% load(['./FSDsmall.mat'],'FSDsmall');load(['./FSDmedium.mat'],'FSDmedium');load(['./FSDlarge.mat'],'FSDlarge');
% edges = logspace( -1 , 1, 31 );
% bins = (edges(2:end)+edges(1:end-1))/2;
% %fig(1) = loglog(bins(11:end),FSDlarge(11:end),'linewidth',2);
% fig(2) = loglog(bins(11:end),FSDmedium(11:end),'linewidth',2);
% fig(3) = loglog(bins(11:end),FSDsmall(11:end),'linewidth',2);

binsUpper = bins(bins>0); slopes1 = -2.2;
fig(4) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
patch = fill(x_vector1, y_vector1, options.color_area1); 
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
hold on
set(patch, 'edgecolor', 'none');
set(patch, 'FaceAlpha', options.alpha); hold on
patch2 = fill(x_vector, y_vector, options.color_area2);
set(patch2, 'edgecolor', 'none');
set(patch2, 'FaceAlpha', options.alpha); hold on

lgd = legend('Terra','Sentinel-2');%,'L^{-2.2}');
fontsize(lgd,20,'points')
legend('boxoff')
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
set(gca,'fontsize',22);
xlim([1e-1 1e1])
ylim([1e-5 20])
ylabel({'FSD (floes per km$^2$)'},'fontsize',24,'interpreter','latex')
xlabel('Floe Size (km)','fontsize',24,'interpreter','latex')
box on
fig = figure(1);
set(0, 'DefaultFigureRenderer', 'painters');
exportgraphics(fig,'FSDpatch.pdf' ,'resolution',300);

%% 
for jj = 1:312
    close all
    load(['./small/Floe' num2str(jj,'%07.f') '.mat'])
    FloeL = [];
    keep = zeros(1,length(Floe));
    for ii = 1+Nb:length(Floe)
        if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-2.5e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-0.5e5 %&& min(Floe(ii).c_alpha(1,:))+Floe(ii).Xi>-5.5e4 && max(Floe(ii).c_alpha(1,:))+Floe(ii).Xi<4.5e4
            FloeL = [FloeL Floe(ii)];
            keep(ii) = 1;
        end
    end
    %create boundary polyshape
    keep = logical(keep);
    FloeOut = Floe(~keep);
    clear poly
    for ii =1:length(FloeOut)
        poly(ii) = polyshape(FloeOut(ii).c_alpha'+[FloeOut(ii).Xi FloeOut(ii).Yi]);
    end
    y_low = [-2.5e5 -0.5e5 -0.5e5 -2.5e5];
    x_low = [-1e5 -1e5 1e5 1e5];
    % y_low = [-1.35e5 -0.5e5 -1.35e5 -2e5 -1.35e5]-1.2e5;
    % x_low = [-5e4 0 5e4 0 -5e4]-0.5e4;
    lower_box = polyshape([x_low;y_low]');
    for ii = 1:length(poly)
        lower_box = subtract(lower_box,poly(ii));
    end
    lower_box = rmholes(lower_box);
    %A_upper = area(upper_box); A_lower = area(lower_box);
    FloeLp = FloeL; clear FloeL; count = 1;
    for ii = 1:length(FloeLp)
        [in,~] = inpolygon(FloeLp(ii).c_alpha(1,:)'+FloeLp(ii).Xi,FloeLp(ii).c_alpha(2,:)'+FloeLp(ii).Yi,x_low, y_low);
        if sum(in)/length(in) == 1
            FloeL(count) = FloeLp(ii);
            count = count+1;
        end
    end
    clear polyL
    for ii =1:length(FloeL)
        polyL(ii) = polyshape(FloeL(ii).c_alpha'+[FloeL(ii).Xi FloeL(ii).Yi]);
    end
    edges = logspace( -1 , 1, 31 );
    bins = (edges(2:end)+edges(1:end-1))/2;
    Areas3 = cat(1,FloeL.area); %Find areas of segmented floes
    Anorm = Areas3(Areas3>1e6);
    A_lower = sum(Anorm);
    a3 = sqrt(cat(1,Areas3));
    hFSD3 = histogram(a3/1e3,edges);
    edges3 = hFSD3.BinEdges;
    val3 = hFSD3.Values;
    clear FSD
    count3 = 1;
    %Loop through to find floe sizes per km^2
    for ii = 1:length(val3)
        FSD(count3) = sum(val3(ii:end))/(A_lower)*1e6;
        count3 = count3+1;
    end
    save(['./small/FSD' num2str(jj,'%07.f') '.mat'],'FSD','bins');
end
%% 

edges = logspace( -1 , 1, 31 );
bins = (edges(2:end)+edges(1:end-1))/2;

count = 1; FSDs=[];
for ii = 313:20:493
    load(['./large2/FSD' num2str(ii,'%07.f') '.mat'],'FSD');
    FSDs(count,:) = FSD;
    count = count + 1;
end

[m,n] = size(FSDs);
clear FSDmean
for ii = 1:n
    FSDmean(ii) = mean(FSDs(:,ii));
end

FSDaltLarge = FSDmean;
save('FSDaltLarge.mat','FSDaltLarge','bins')

close all
figure;
hold on
fig(1) = loglog(bins,FSDmean,'linewidth',2);
xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
binsUpper = bins(bins>0); slopes1 = -2;
fig(2) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
% load('./Modis/FSDobs.mat','FSDmean','FSDerror','bins')
% errorbar(bins,FSDmean,FSDerror)
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
xlim([5*10.^-1 10])
ylim([10.^-3 1])
legend('mean','slope=-2','Observations', 'fontsize',16)
legend('boxoff')
%% 
edges = logspace( -1 , 1, 31 );
bins = (edges(2:end)+edges(1:end-1))/2;
count = 1;
clear FSDs
for ii = 400:500
    load(['FSD' num2str(ii,'%07.f') '.mat'],'FSD');
    FSDs(count,:) = FSD; count = count + 1;
end

[m,n] = size(FSD);
clear FSDmeanSmall
for ii = 1:n
    FSDmeanSmall(ii) = mean(FSD(:,ii));
end
save('/Users/bmontemuro/Documents/Nares_Paper_Figs/FSDmeanSmall.mat','bins','FSDmeanSmall')
%%
%bins = (edges(2:end)+edges(1:end-1))/2;
close all
% x1 = log10(bins); y1 = log10(FSD);
% plot(x1,y1)
% x1 = x1(1:22);y1 = y1(1:22);
% %x1(isinf(y1)) = [];y1(isinf(y1)) = [];
% f = fit(x1',y1','poly1'); plot(x1,y1)
% m = f.p1;
t = datetime(2023,07,14);
t2 = datetime(07,14);
save('FSD20230714','FSD','bins','m','t','bwt','maxNumErosions');
%%
FloeL = [];
for ii = 1+Nb:length(Floe)
    if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-2.5e5 %&& max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-0.5e5 %&& min(Floe(ii).c_alpha(1,:))+Floe(ii).Xi>-5.5e4 && max(Floe(ii).c_alpha(1,:))+Floe(ii).Xi<4.5e4
        FloeL = [FloeL Floe(ii)];
    end
end

%% 

for k = 1:177
    xk = x{k};
    yk = y{k};
    poly(k) = polyshape(xk,yk);
end
xb = [-5e5 -5e5 0 0];
yb = [-1.1e6 -0.6e6 -0.6e6 -1.1e6];
box = polyshape(xb,yb);
count = 1;
for k = 1:177
    A = area(intersect(box,poly(k)));
    if A > 0
        Nares(count) = poly(k);
        count = count+1;
    end
end
%% 
boundary = box2.Vertices'/3;
Lx = max(boundary(1,:));
Ly = max(boundary(2,:));
N = 2000;
X = 0.975*Lx*(2*rand(N,1)-1);
Y = 0.975*Ly*(2*rand(N,1)-1);
[~, b,~,~,~] = polybnd_voronoi([X Y],boundary');

%% 

clear poly
for ii = 1:length(b)
    if ~isnan(b{ii})
        poly(ii) = polyshape(b{ii});
    end
end
poly0 = poly;
poly1 = translate(poly0,[2*Lx 0]);
poly2 = translate(poly0,[2*Lx -2*Ly]);
poly3 = translate(poly0,[0 -2*Ly]);
poly4 = translate(poly0,[-2*Lx -2*Ly]);
poly5 = translate(poly0,[-2*Lx 0]);
poly6 = translate(poly0,[-2*Lx 2*Ly]);
poly7 = translate(poly0,[0 2*Ly]);
poly8 = translate(poly0,[2*Lx 2*Ly]);
poly = [poly0, poly1, poly2, poly3, poly4, poly5, poly6, poly7, poly8];
plot(poly)
pnew = translate(poly,[xc,yc]);

%% 
count = 1; count2 = 1;
icex = x(bw);
icey = y(bw);
clear polyStart; clear polyDiscard
close all
for k = 1:length(pnew)
    Anew = subtract(pnew(k),Nares);
    if area(Anew) > 0
        [in,~] = inpolygon(icex,icey,Anew.Vertices(:,1), Anew.Vertices(:,2));
        [in2,~] = inpolygon(x(:),y(:),Anew.Vertices(:,1), Anew.Vertices(:,2));
        if sum(in)/sum(in2)>0.5
            polyStart(count) = Anew;
            count = count+1;
        elseif sum(in)/sum(in2)<0.4
            polyDiscard(count2) = Anew;
            count2 = count2+1;
        end
    end
end
plot(polyStart); hold on
plot(Nares)
figure
plot(polyDiscard)

% kill = zeros(1,length(polyStart));
% for ii = 1:length(polyStart)
%     [in,~] = inpolygon(icex,icey,polyStart(ii).Vertices(:,1), polyStart(ii).Vertices(:,2));
%     if sum(in)>0
%         kill(ii) = 1;
%     end
% end
% kill = logical(kill);
% polyNares = polyStart(~kill);
% plot(polyNares)
%% 
boundary = poly4.Vertices';
Lx = max(abs(boundary(1,:)));
Ly = max(abs(boundary(2,:)));
boundaryx = Lx*[-1 -1 1 1];
boundaryy = Ly*[-1 1 1 -1];
boundary = [boundaryx; boundaryy];
N = 1500;
X = 0.975*Lx*(2*rand(N,1)-1);
Y = 0.975*Ly*(2*rand(N,1)-1);
[~, b,~,~,~] = polybnd_voronoi([X Y],boundary');

clear pnew
for ii = 1:length(b)
    if ~isnan(b{ii})
        pnew(ii) = polyshape(b{ii});
    end
end

for ii = 1:length(Floe)
    Floe(ii).StressH = 25;
end

Nares = union(R);
count = 1; 
clear polyStart; 
close all
for k = 1:length(pnew)
    Anew = intersect(pnew(k),poly4);
    if area(Anew) > 0
        polyStart(count) = Anew;
        count = count+1;
    end
end
plot(polyStart)
hold on
plot(R)
%% 
FloeL = [];
for ii = 1+Nb:length(Floe)
    if  max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<1e5
        FloeL = [FloeL Floe(ii)];
    end
end

clear Princ
for ii = 1:length(FloeL)
    Stress = eig(FloeL(ii).Stress)/FloeL(ii).h;
    Princ(ii,1) = max(Stress);
    Princ(ii,2) = min(Stress);
    Princ(ii,3) = FloeL(ii).area;
end
Princ1 = Princ(:,1); Princ2 = Princ(:,2);

Pstar = 1.4e4; C = 20; concentration = 1;%Pstar = 1.1e4 to low
P = Pstar*exp(-C*(1-concentration));
t = linspace(0,2*pi) ;
a = P*sqrt(2)/2 ; b = a/2 ;
x = a*cos(t) ;
y = b*sin(t) ;
Mohr = polyshape(x,y);
Mohr = rotate(Mohr,45);
Mohr = translate(Mohr, [-P/2, -P/2]);

close all
plot(Mohr)
hold on
plot(Princ1,Princ2,'kx','linewidth',2)
%%
FloeFill = [];
for ii = 1+Nb:length(Floe)
    if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>1.5e5 
        FloeFill = [FloeFill Floe(ii)];
    end
end
FloeO = Floe;
y = cat(1,Floe.Yi);
in = ones(1,length(y));
in(y>2e5) = 0;
in = logical(in);
Floe = Floe(in);
%%
close all

%yyaxis right
load('MomentumBudget10.mat','dpdt','Ocn','Atm','coast','islands','time')
%load('MomentumBudget10Alt.mat','dpdt','Ocn','Atm','coast','islands','time')

islands(islands<0)=0;
figure
x = time/24/3600;
Y = [movmean(islands(1,:),3); movmean(islands(2,:),3); movmean(islands(4,:),3); movmean(islands(3,:),3)];

area(x,Y','LineStyle','none')
ylabel('Force (N)','fontsize',20)
xlabel('Time (days)','fontsize',20)
set(gca,'fontsize',24);
ylim([0 3.5e8])
xlim([2 10])
tdif = 1:495;
%load('ni10.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
%A_flux5 = A_total_flux_L+A_flux_L_tmp;
%t5 = t_flux/24/3600;
load('transportNI.mat','transport','time');
transportNI = transport(tdif); timeNI = time(tdif);
A_flux5 = diff(transportNI)./diff(timeNI)/1e6;
A_flux5 = movmean(A_flux5,3);
%t5 = (0:248)*5*350/24/3600;
t5 = (timeNI(1:end-1)+timeNI(2:end))/2;

% load('i10.mat','Floe','Nb','A_total_flux_L','A_flux_L_tmp','t_flux')
% A_flux6 = A_total_flux_L+A_flux_L_tmp;
% t6 = t_flux/24/3600;
load('transportI.mat','transport','time');
transportI = transport(tdif); timeI = time(tdif);
A_flux6 = diff(transportI)./diff(timeI)/1e6;
A_flux6 = movmean(A_flux6,3);
%t6 = (0:248)*5*350/24/3600;
t6 = (timeI(1:end-1)+timeI(2:end))/2;
hold on
rho_ice=920; h = mean(cat(1,Floe.h));
yyaxis right
%plot(t5,A_flux5,'linewidth',3);hold on;
plot(t6,A_flux6,'k','linewidth',3);
ylim([0 800])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Flux (km$^2$/day)','Color','k','fontsize',20,'interpreter','latex')
set(gca,'YColor','k');

lgd = legend({'Hannah','Hans', 'Franklin', 'Crozier','Area Flux'});
%lgd = legend({'Hannah','Hans', 'Franklin', 'Crozier','No Islands','Islands'});
lgd = legend('box','off');
fontsize(lgd,18,'points');
box on
set(gca,'fontsize',18);
fig = figure(1)
exportgraphics(fig,['IslandBreakdown.jpg']);
%%
close all
edges = 0:75:1000;
%edges = logspace( 0 , 2.5, 31 );
tdif = 100:495;
load('transportI.mat','transport','time');
transportI = transport(tdif); timeI = time(tdif);
A_flux5 = diff(transportI)./diff(timeI)/1e6;

load('transportNI.mat','transport','time');
transportNI = transport(tdif); timeNI = time(tdif);
A_flux6 = diff(transportNI)./diff(timeNI)/1e6;
h = histogram(A_flux6,edges,'FaceColor','k','Normalization','pdf');
%p1 = histcounts(A_flux6,edges,'Normalization','pdf');
hold on
h2 = histogram(A_flux5,edges,'FaceColor',[91, 207, 244] / 255,'Normalization','pdf');
%p2 = histcounts(A_flux5,edges,'Normalization','pdf');
legend('No Islands','Islands','fontsize',20)
legend('boxoff')
set(gca,'fontsize',18);
xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
ylabel('Probability Density','fontsize',20,'interpreter','latex')
%set(gca, 'xScale', 'log')
box on

% figure
% binCenters = (edges(2:end)+edges(1:end-1))/2;
% %binCenters = h.BinEdges + (h.BinWidth/2);
% plot(binCenters, p1, 'linewidth', 2); hold on
% plot(binCenters, p2, 'linewidth', 2); 
% legend('No Islands','Islands','fontsize',20)
% legend('boxoff')
% set(gca,'fontsize',18);
% xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
% %set(gca, 'xScale', 'log')
% box on
fig = figure(1);
exportgraphics(fig,['FluxHistogramIslands.jpg']);
%%
load('transportNI.mat','transport'); TransportNI = transport;
load('transportI.mat','transport'); TransportI = transport;
tvals = 1:15:length(t5); tvals2 = 1:15:length(t6);
Transport1 = TransportNI(tvals); t1 = t5(tvals);time1 = (t1(2:end)+t1(1:end-1))/2; tdif = t5(tvals(2))-t5(1); T1diff = Transport1(2:end)-Transport1(1:end-1); flux1 =T1diff/tdif;
Transport2 = TransportI(tvals2); t2 = t6(tvals); time2 = (t2(2:end)+t2(1:end-1))/2; tdif2 = t6(tvals2(2))-t6(1); T2diff = Transport2(2:end)-Transport2(1:end-1); flux2 =T2diff/tdif2;
figure(2); hold off
plot(time1,flux1/1e6,'linewidth',2);hold on;
plot(time2,flux2/1e6,'linewidth',2)
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')

lgd = legend({'No Islands','Islands'});
lgd = legend('box','off');
fontsize(lgd,24,'points');
box on
set(gca,'fontsize',18);

%%
addpath('/home/bpm5026/nares_idealized_winds/nares_10_islands/Initialize_Model/') 
addpath('/home/bpm5026/nares_idealized_winds/nares_10_islands/Nares/') 
c2_boundary=initialize_boundaries_Nares();
c2_boundary_poly = polyshape(c2_boundary');
ymin = min(c2_boundary(2,:));
y_low = [-1.8e5 ymin ymin -1.8e5];
x_low = [-1e5 -1e5 1e5 1e5];
lower_box = polyshape([x_low;y_low]');
transport = zeros(1,249); time = transport;
load(['/dat1/bpm5026/Paper2runs/islands10/Floe0000001.mat'],'Floe','Nb','t_flux');
T0 = 0;
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
        T0 = T0 + Floe(ii).area;
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
        Anow = area(intersect(poly,lower_box));
        T0 = T0 + Anow;
    end
end
for jj = 1:495
    load(['/dat1/bpm5026/Paper2runs/islands10/Floe' num2str(jj,'%07.f') '.mat'],'Floe','Nb','t_flux');

    Areas = 0;

    for ii = 1+Nb:length(Floe)
        if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5
            Areas = Areas + Floe(ii).area;
        elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1.8e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-1.8e5
            poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
            Anow = area(intersect(poly,lower_box));
            Areas = Areas + Anow;
        end
    end
    time(jj) = (jj-1)*5*350/24/3600;
    transport(jj) = Areas-T0;
end
save('/dat1/bpm5026/Paper2runs/islands10/transportNI.mat','transport','time');
%%
close all
T = readtable('NaresStrait_iaf_20160901-20190831.csv');
%data2017 = T(171:443,:); data2017(59,:) = []; data2017(33,:) = []; data2017(24,:) = []; data2017(16,:) = [];
%data2017 = T(171:588,:); data2017(59,:) = []; data2017(33,:) = []; data2017(24,:) = []; data2017(16,:) = [];
data2017 = T(290:481,:); data2017(59,:) = []; data2017(33,:) = []; data2017(24,:) = []; data2017(16,:) = [];
ice_flux = data2017(:,10); month = data2017(:,2); day = data2017(:,3); hour = data2017(:,4); 
ice_velocities = data2017(:,9); ice_velocities = table2array(ice_velocities); ice_vel_2017 = ice_velocities*1000/(24*3600);
year = data2017(:,1); 
iceflux2017 = table2array(ice_flux); Month = table2array(month); Day = table2array(day); Hour = table2array(hour);
Year = table2array(year); date2017 = datetime(Year,Month,Day); date2017_ice = date2017;
clear t;
DateNumber = datenum(date2017); DateNumber= DateNumber-DateNumber(1);
t = DateNumber*24+Hour-Hour(1);
flux=interp1(t,iceflux2017,Time_ice_new);
velocities=interp1(t,ice_vel_2017,Time_ice_new);
Time = Time_ice_new*3600;

T2 = readtable('aws02Weather_2017_bpm.csv');
% Y2017 = T2(952:8887,:);
Y2017 = T2(952:7959,:);
Y2017 = sortrows(Y2017,2);
dir = Y2017(:,12); WindSpeed = Y2017(:,10);
directions = table2array(dir); WindSpeed = table2array(WindSpeed); 
Date  = Y2017(:,1); %Date = flipud(Date); 
date2017 = table2array(Date); [h,m,s] = hms(date2017);
DateNumber = datenum(date2017); DateNumber= DateNumber-DateNumber(1);
t2017_winds = DateNumber*24;
%t_winds = t_winds*3600;
directions = directions-90-33;
directions(directions<0) = directions(directions<0) +360;
winds2017_v = WindSpeed.*sin(directions*pi/180);
winds2017=interp1(t2017_winds,winds2017_v,T_wind_new)*0.02;
%winds2017=interp1(t2017_winds,winds2017_v,T_wind)*0.0003;
Time_wind = T_wind_new*3600;

yyaxis left
plot(date2017_ice,iceflux2017,'linewidth',2); hold on
ylim([-4000 4000])
set(gca, 'YDir','reverse') 
box on
set(gca,'fontsize',18);
ylabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
yyaxis right
plot(date2017,winds2017_v,'linewidth',2)
ylabel('Wind Speed (m/s)','fontsize',20,'interpreter','latex')

fig = figure(1);
exportgraphics(fig,['SummerForcing.jpg']);
%%
addpath('/Users/bmontemuro/Downloads/collab/Initialize_Model') 
addpath('/Users/bmontemuro/Downloads/collab/Physical_Processes') 
addpath('/Users/bmontemuro/Downloads/collab/polygon_operations') 
for ii = 1:1000
    [Floe,Princ,FracData] = fracture(FloeOld,Nb,min_floe_size,compactness,FracData);
    if sum(cat(1,Floe.area))/sum(cat(1,FloeOld.area))<0.9995
        error()
    end
end
%%
close all
dt=10; %Time step in sec
height.mean = 0.25; %mean value of thickness for initial floes
height.delta = 0; %maximum deviation about the mean thickness if a distribution is desired
nDTpack = 500; %Time streps between creation of new floes
[ocean, HFo, h0]=initialize_ocean(dt,nDTpack); %Define ocean currents
c2_boundary=initialize_boundaries();
c2_boundary_poly = polyshape(c2_boundary');
fig = 0; Nb = 0; PERIODIC=false;
Time = 0;
for im_num = 1:488
    load(['./floes/Floe' num2str(im_num,'%07.f') '.mat'],'Floe','FracData');
    [fig] = plot_basic(fig, Time,Floe,ocean,c2_boundary_poly,Nb,PERIODIC);
    exportgraphics(fig,['./figs/' num2str(im_num,'%03.f') '.jpg'] ,'resolution',200);
end