%This function creates plots of the floe state showing the stress and and
%thickness of the floes

paths
c2_boundary=initialize_boundaries_Nares();
f=2*pi/(24*3600);
Ly = max(c2_boundary(2,:));Lx = max(c2_boundary(1,:));
%% Set Up The Plots

ratio=(Ly+2.5e5)/(2*Lx);
fig=figure('Position',[10 10 200 200*ratio],'visible','on');  
set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
set(gca,'color','k')
figure(fig)
clf(fig);

hold on;

load('FloeStartIslandsPartial.mat','Floe','Nb');
for ii =1:length(Floe)
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end

plot([Floe(1+Nb:end).poly],'FaceColor','k','FaceAlpha',0.3,'EdgeColor',[1 1 1]*0.2,'linewidth',0.2);
if Nb > 0
    plot([Floe(1:Nb).poly],'FaceColor',[0 0.2 0],'FaceAlpha',0.75,'linestyle','none');
end

colormap('gray'); caxis([0 1]);
axis([-Lx Lx -Ly Ly])
xlabel('m');ylabel('m');
set(gca,'Ydir','normal');
set(gca,'fontsize',18);
box on
ylim([-Ly 2.5e5])

set(0, 'DefaultFigureRenderer', 'painters');
exportgraphics(fig,'Nares_domain.pdf' ,'resolution',300);
