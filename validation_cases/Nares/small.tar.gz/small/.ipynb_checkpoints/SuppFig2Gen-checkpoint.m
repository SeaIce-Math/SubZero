close all
fig = figure;
hold on

%% Fig 5a
load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
A_flux = A_total_flux+A_flux_tmp;
A_flux = A_flux-A_flux(2); A_flux(1) = 0;
t = t_flux/24/3600;
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlt2/Floe0000493.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux3 = A_total_flux+A_flux_tmp;
A_flux3 = A_flux3-A_flux3(3); A_flux3(1) = 0;A_flux3(2) = 0;
t3 = t_flux/24/3600;
i_flux_tot = 0; i_flux_tot2 = 0;
for kk = 2:length(i_flux)
    i_flux_tot(kk) = i_flux_tot(kk-1)+i_flux(kk)*(T_flux(kk)-T_flux(kk-1))*1e6;
    i_flux_tot2(kk) = trapz(T_flux(1:kk),i_flux(1:kk))*1e6;
end
rho_ice=920; h = mean(cat(1,Floe.h));
plot(t3,(A_flux3-A_flux3(520))/1e6,'b','linewidth',2); hold on
plot(T_flux-T_flux(1),i_flux_tot2/1e6-300,'b--','linewidth',2)
set(gca,'fontsize',16);
ylim([0 9000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Sea Ice Area Transported (km$^2$)','fontsize',20,'interpreter','latex')


t2 = T_flux(1:12)-T_flux(1);
i_flux_tot3 = zeros(1,length(t2));
Fluxq = i_flux_tot3;
for ii=1:length(t2)
    [~,I2] = min(abs(t3-t2(ii)));
    i_flux_tot3(ii) = A_flux3(I2)-A_flux3(520);
end
Fluxq(2:end) = i_flux_tot3(2:end)-i_flux_tot3(1:end-1);
hold on
yyaxis right
hline = plot(t2(2:end),Fluxq(2:end)/1e9,'linewidth',1.75);
hline2 = plot(T_flux(2:end)-T_flux(1),i_flux(2:end)/1e3,'linewidth',1.75);
for i=1:length(hline)
    hline(i).Color = [hline(i).Color 0.3];  % alpha=0.1
    hline2(i).Color = [hline2(i).Color 0.3];  % alpha=0.1
end
ylabel('Area Flux (10^3 km^2/day)','fontsize',16)
ylim([0 5])
xlim([0 t3(end)])
legend('SubZero-Transport','Observations-Transport','SubZero-Flux','Observations-Flux','fontsize',18)
legend('boxoff')
legend('Location','northwest')
fig = figure(1);
exportgraphics(fig,['Fig5a.jpg'] ,'resolution',300);


%% Fig 5b
close all
fig = figure;
bins = 0:250:3000;
load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
tvals = 6900:100:length(t3);
Transport1 = A_flux3(tvals)/1e6; tdif = t(tvals(2))-t(tvals(1)); T1diff = Transport1(2:end)-Transport1(1:end-1); flux1 =T1diff/tdif;
h = histogram(flux1,bins,'FaceColor','r','Normalization','pdf');
%p1 = histcounts(flux1,bins,'Normalization','pdf');
hold on
h3 = histogram(i_flux,bins,'FaceColor','b','Normalization','pdf');
%p3 = histcounts(i_flux,bins,'Normalization','pdf');
%figure
%binCenters = h.BinEdges + (h.BinWidth/2);
%plot(binCenters(1:end-1), p1, 'linewidth', 2); hold on
%plot(binCenters(1:end-1), p3, 'linewidth', 2)
legend('SubZero','Observations','fontsize',20)
legend('boxoff')
set(gca,'fontsize',18);
xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
ylabel('Probability Density','fontsize',20,'interpreter','latex')
box on
exportgraphics(fig,['Fig5b.jpg']);

%close all
%edges = 0:75:1000;
%tdif = 100:495;
%load('transportI.mat','transport','time');
%transportI = transport(tdif); timeI = time(tdif);
%A_flux5 = diff(transportI)./diff(timeI)/1e6;

%load('transportNI.mat','transport','time');
%transportNI = transport(tdif); timeNI = time(tdif);
%A_flux6 = diff(transportNI)./diff(timeNI)/1e6;
%h = histogram(A_flux6,edges,'FaceColor','k','Normalization','pdf');
%p1 = histcounts(A_flux6,edges,'Normalization','pdf');
%hold on
%h2 = histogram(A_flux5,edges,'FaceColor',[91, 207, 244] / 255,'Normalization','pdf');
%p2 = histcounts(A_flux5,edges,'Normalization','pdf');
%legend('No Islands','Islands','fontsize',20)
%legend('boxoff')
%set(gca,'fontsize',18);
%xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
%ylabel('Probability Density','fontsize',20,'interpreter','latex')
%%set(gca, 'xScale', 'log')
%box on