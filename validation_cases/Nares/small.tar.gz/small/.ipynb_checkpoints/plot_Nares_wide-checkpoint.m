paths
c2_boundary=initialize_boundaries_Nares();
Ly = max(c2_boundary(2,:));Lx = max(c2_boundary(1,:));
ratio=(Ly+2.5e5)/(2*Lx);
fig = 0;
%ratio = abs(-1.5e5)/(Lx); %Ly/Lx;%
if (fig==0 || ~isvalid(fig))
    fig=figure('Position',[10 10 200 200*ratio],'visible','on');  
    set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
end
figure(fig)
clf(fig);

dn=1; % plot every dn'th velocity vector
% %quiver(ocean.Xo(1:dn:end),ocean.Yo(1:dn:end),ocean.Uocn(1:dn:end,1:dn:end),ocean.Vocn(1:dn:end,1:dn:end));
hold on;

%axis([ocean.Xo(1) ocean.Xo(end) ocean.Yo(1) ocean.Yo(end)]);

colormap('gray'); caxis([0 1]);

load('FloeStartIslandsPartial.mat','Floe','Nb');
for ii =1:length(Floe)
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
    Stress(ii) = max(abs(eig(Floe(ii).Stress)));
end

A = cat(1,Floe.area);

load('./plotting/NaresGLwide.mat'); load('./plotting/NaresCAwide.mat'); load('./plotting/NaresISwide.mat');% 
NaresIm2 = naresGLwide+naresCAwide+naresISwide;
[Ny,Nx,Nz] = size(NaresIm2);
NaresIm3 = ones(Ny,Nx,Nz,'uint8');
%NaresIm2 = naresISwide;
col = [10    18    29];
for ii = 1:3
    in1 = NaresIm2(:,:,ii); in1(in1==0)=col(ii);
    in2 = NaresIm3(:,:,ii)*col(ii);
    NaresIm2(:,:,ii) = [in1];  
    NaresIm3(:,:,ii) = [in2];  
end

image(xc,yc,NaresIm2)
set(gca, 'ydir', 'normal')
hold on; 
image(xc,yc-4e5,NaresIm3)
image(xc,yc-8e5,NaresIm3)
plot([Floe(1+Nb:end).poly],'FaceColor',[184 194 195]/256,'FaceAlpha',1,'EdgeColor',[1 1 1]*0.3,'linewidth',0.3);

%hold on; 
%clear poly_bound
%for iii = 1:Nb
%    poly_bound(iii) = polyshape(Floe(iii).c_alpha'+[Floe(iii).Xi Floe(iii).Yi]);
%end
%plot(R,'FaceColor',[1 1 1],'FaceAlpha',0.5,'EdgeAlpha',0.5);
axis([-Lx Lx -Ly Ly])
xlabel('m');ylabel('m');
set(gca,'Ydir','normal');
set(gca,'fontsize',18);
box on
ylim([-Ly 2.5e5])

set(0, 'DefaultFigureRenderer', 'painters');
exportgraphics(fig,'Nares_domain_nice.pdf' ,'resolution',300);


%% 
%B = load('arcticborderdata.mat'); 
% Unproject and reproject if necessary: 
%for k = 1:length(x)
%    Arctic(k) = polyshape(x{k},y{k});
%end
%Gl = Arctic(51);

ny = 370; y1 = 984; nx = 243; x1 = 240;
%Lx= max(c2_boundary_poly.Vertices(:,1)); %c2 must be symmetric around x=0 for channel boundary conditions.
%Ly= max(c2_boundary_poly.Vertices(:,2)); 
x_nares=[-1 -1 1 1 -1]*Lx;
y_nares=[-1 1 1 -1 -1]*Ly;
xc = min(x_nares):(max(x_nares)-min(x_nares))/(nx-1):max(x_nares);
yc = min(y_nares):(max(y_nares)-min(y_nares))/(ny-1):max(y_nares);
yc = fliplr(yc);
nares = NaresIm2(y1:y1+ny,x1:x1+nx,:);
KennedyISwide = nares;
%save('./plotting/KennedyGLwide.mat','KennedyGLwide','xc','yc')
%nares = NaresIm2;
image(xc,yc,nares)