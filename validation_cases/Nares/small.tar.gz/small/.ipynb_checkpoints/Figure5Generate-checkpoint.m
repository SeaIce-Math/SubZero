fig = figure;
hold on

load('./dat1/bpm5026/Paper2runs/nares_small/FloesPaper/Floe0000500.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
load('obs_flux.mat')
A_flux = A_total_flux+A_flux_tmp; %A_flux(1) = 0;
%A_flux(2:end) = A_total_flux(2:end)-A_total_flux(1:end-1);
t = t_flux/24/3600;
t2 = fix(t_flux/(6*3600));
count = 1;
clear Aflux2; clear time
for kk = 1:max(t2)
    A_tot = A_flux(t2==kk);
    Aflux2(count) = (A_tot(end)-A_tot(1))*4/(1e9);
    time(count) = kk*6/24;
    count = count+1;
end

rho_ice=920; h = mean(cat(1,Floe.h));
yyaxis left
plot(t,(A_total_flux+A_flux_tmp)*rho_ice*h,'linewidth',2)
set(gca,'fontsize',18);
ylim([0 6e12])
ylabel('Mass (kg)','fontsize',16)
hold on
yyaxis right
hline = plot(time,Aflux2,'linewidth',1.75);
hline2 = plot(T_flux-T_flux(1),i_flux/1000,'linewidth',1.75);
%hline = plot(t,A_flux*1000/(1e6*3600*24),'linewidth',1.75);
ylim([-0.5 3])
for i=1:length(hline)
    hline(i).Color = [hline(i).Color 0.3];  % alpha=0.1
    hline2(i).Color = [hline2(i).Color 0.3];  % alpha=0.1
end
ylabel('Area Flux (10^3 km^2/day)','fontsize',16)
xlabel('Time (days)','fontsize',16)
xlim([0 14])
AvObs = 0.5*ones(1,length(t));
Av = (A_total_flux(end)+A_flux_tmp(end))/t(end)/1e9
% plot(t,AvObs,'k--','linewidth',2)
exportgraphics(fig,['flux.jpg'] ,'resolution',300);