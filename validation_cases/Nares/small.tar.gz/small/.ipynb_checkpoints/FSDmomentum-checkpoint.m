Find FSDs

close all

y_low = [-2.5e5 0.5e5 0.5e5 -2.5e5];
x_low = [-1e5 -1e5 1e5 1e5];

lower_box = polyshape([x_low;y_low]');

load(['/dat1/bpm5026/nares_momentum_new/Floe0000244.mat'],'Floe','Nb');
FloeL = [];
keep = zeros(1,length(Floe));
for ii = 1+Nb:length(Floe)
    if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-2.5e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-0.5e5 
        FloeL = [FloeL Floe(ii)];
        keep(ii) = 1;
    end
end

%create boundary polyshape
keep = logical(keep);
FloeOut = Floe(~keep);
clear poly
for ii =1:length(FloeOut)
    poly(ii) = polyshape(FloeOut(ii).c_alpha'+[FloeOut(ii).Xi FloeOut(ii).Yi]);
end

for ii = 1:length(poly)
    lower_box = subtract(lower_box,poly(ii));
end
lower_box = rmholes(lower_box);
%A_upper = area(upper_box); A_lower = area(lower_box);

FloeLp = FloeL; clear FloeL; count = 1;
for ii = 1:length(FloeLp)
    [in,~] = inpolygon(FloeLp(ii).c_alpha(1,:)'+FloeLp(ii).Xi,FloeLp(ii).c_alpha(2,:)'+FloeLp(ii).Yi,x_low, y_low);
    if sum(in)/length(in) == 1
        FloeL(count) = FloeLp(ii);
        count = count+1;
    end
end

clear polyL
for ii =1:length(FloeL)
    polyL(ii) = polyshape(FloeL(ii).c_alpha'+[FloeL(ii).Xi FloeL(ii).Yi]);
end

edges = logspace( -1 , 1, 31 );
bins = (edges(2:end)+edges(1:end-1))/2;

Areas3 = cat(1,FloeL.area); %Find areas of segmented floes
A_lower = sum(Areas3);
a3 = sqrt(cat(1,Areas3));
hFSD3 = histogram(a3/1e3,edges);
edges3 = hFSD3.BinEdges;
val3 = hFSD3.Values;
clear FSDsmall
clear FSDsmall2
count3 = 1;
%Loop through to find floe sizes per km^2
for ii = 1:length(val3)
    FSDsmall(count3) = sum(val3(ii:end))/(A_lower)*1e6;
    % FSDsmall2(count3) = sum(val3(ii:end));
    count3 = count3+1;
end
save(['./FSDsmall.mat'],'FSDsmall');

%% Fig 5a
colororder({'r','b','r'})
close all
clear all
fig = figure;
ax = gca();      % the current axes is the left axes at this point
ax.YColor = 'b'; % set the left axes YColor to black
hold on
load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
%A_flux = A_total_flux+A_flux_tmp;
%A_flux = A_flux-A_flux(2); A_flux(1) = 0;
%t = t_flux/24/3600;
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlpha0/Floe0000460.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux2 = A_total_flux+A_flux_tmp;
A_flux2 = A_flux2-A_flux2(3); A_flux2(1) = 0;A_flux2(2) = 0;
t2 = t_flux/24/3600;
load('/dat1/bpm5026/nares_momentum_new/Floe0000460.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux3 = A_total_flux+A_flux_tmp;
A_flux3 = A_flux3-A_flux3(3); A_flux3(1) = 0;A_flux3(2) = 0;
t3 = t_flux/24/3600;
i_flux_tot = 0; i_flux_tot1 = 0;
for kk = 2:length(i_flux)
    i_flux_tot(kk) = i_flux_tot(kk-1)+i_flux(kk)*(T_flux(kk)-T_flux(kk-1))*1e6;
    i_flux_tot1(kk) = trapz(T_flux(1:kk),i_flux(1:kk))*1e6;
end
rho_ice=920; h = mean(cat(1,Floe.h));
yyaxis('left');
ax = gca();      % the current axes is the left axes at this point
ax.YColor = 'b'; % set the left axes YColor to black
plot(T_flux-T_flux(1),i_flux_tot1/1e6-300,'b','linewidth',2)
plot(t2,(A_flux2-A_flux2(520))/1e6,'b--','linewidth',2); hold on
plot(t3,(A_flux3-A_flux3(520))/1e6,'b:','linewidth',2); hold on
set(gca,'fontsize',16);
ylim([0 9000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Sea Ice Area Transported (km$^2$)','fontsize',20,'interpreter','latex')


T2 = T_flux(1:12)-T_flux(1);
i_flux_tot2 = zeros(1,length(T2));
i_flux_tot3 = zeros(1,length(T2));
Fluxq = i_flux_tot3;
Fluxq2 = i_flux_tot3;
for ii=1:length(T2)
    [~,I2] = min(abs(t3-T2(ii)));
    i_flux_tot2(ii) = A_flux2(I2)-A_flux2(520);
    i_flux_tot3(ii) = A_flux3(I2)-A_flux3(520);
end
Fluxq2(2:end) = i_flux_tot2(2:end)-i_flux_tot2(1:end-1);
Fluxq(2:end) = i_flux_tot3(2:end)-i_flux_tot3(1:end-1);
hold on
yyaxis right
ax = gca();      % the current axes is the right axes at this point
ax.YColor = 'r'; % set the right axes YColor to black
hline2 = plot(T_flux(2:end)-T_flux(1),i_flux(2:end)/1e3,'r','linewidth',1.75);
hline = plot(T2(2:end),Fluxq2(2:end)/1e9,'r--','linewidth',1.75);
hline1 = plot(T2(2:end),Fluxq(2:end)/1e9,'r:','linewidth',1.75);
for i=1:length(hline)
    hline(i).Color = [hline(i).Color 0.6];  % alpha=0.1
    hline1(i).Color = [hline2(i).Color 0.6];  % alpha=0.1
    hline2(i).Color = [hline2(i).Color 0.6];  % alpha=0.1
end
ylabel('Area Flux (10^3 km^2/day)','fontsize',18)
ylim([0 5])
xlim([0 t3(end)])
legend( 'Observations','SubZero: \beta=0' ,'SubZero: \beta=-1/4','Observations','SubZero: \beta=0' ,'SubZero: \beta=-1/4','fontsize',16)
legend('boxoff')
legend('Location','northwest')
fig = figure(1);
box on
exportgraphics(fig,['FigMomA.jpg'] ,'resolution',300);


%% Fig 5b
close all
figure;
bins = 0:250:3000;
load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
tvals = 6900:100:length(t3);
length(tvals)
Transport2 = A_flux2(tvals)/1e6; tdif2 = t2(tvals(2))-t2(tvals(1)); T2diff = Transport2(2:end)-Transport2(1:end-1); flux2 =T2diff/tdif2;
Transport1 = A_flux3(tvals)/1e6; tdif = t3(tvals(2))-t3(tvals(1)); T1diff = Transport1(2:end)-Transport1(1:end-1); flux1 =T1diff/tdif;
h = histogram(flux1,bins,'FaceColor','r','Normalization','pdf');
p1 = histcounts(flux1,bins,'Normalization','pdf');
hold on
h2 = histogram(flux2,bins,'FaceColor','r','Normalization','pdf');
p2 = histcounts(flux2,bins,'Normalization','pdf');
h3 = histogram(i_flux,bins,'FaceColor','b','Normalization','pdf');
p3 = histcounts(i_flux,bins,'Normalization','pdf');
fig = figure(2);
binCenters = h.BinEdges + (h.BinWidth/2);
plot(binCenters(1:end-1), p3, 'b','linewidth', 2); hold on
plot(binCenters(1:end-1), p2,'b--', 'linewidth', 2); 
plot(binCenters(1:end-1), p1,'b:', 'linewidth', 2);
legend('Observations','SubZero: \beta=0' ,'SubZero: New','fontsize',20)
legend('boxoff')
set(gca,'fontsize',18);
xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
ylabel('Probability Density','fontsize',20,'interpreter','latex')
box on
exportgraphics(fig,['FigMomB.jpg']);

close all
t2(tvals(1))
tdif2
tdif
fig = figure;
plot(Transport2,'b-', 'linewidth', 2);
hold on
plot(Transport1,'r-', 'linewidth', 2);
yyaxis right
plot(flux2,'b:', 'linewidth', 2);
plot(flux1,'r:', 'linewidth', 2);
exportgraphics(fig,['FigMomHistorgram.jpg']);

%edges = 0:75:1000;
%tdif = 100:495;
%load('transportI.mat','transport','time');
%transportI = transport(tdif); timeI = time(tdif);
%A_flux5 = diff(transportI)./diff(timeI)/1e6;

%load('transportNI.mat','transport','time');
%transportNI = transport(tdif); timeNI = time(tdif);
%A_flux6 = diff(transportNI)./diff(timeNI)/1e6;
%h = histogram(A_flux6,edges,'FaceColor','k','Normalization','pdf');
%p1 = histcounts(A_flux6,edges,'Normalization','pdf');
%hold on
%h2 = histogram(A_flux5,edges,'FaceColor',[91, 207, 244] / 255,'Normalization','pdf');
%p2 = histcounts(A_flux5,edges,'Normalization','pdf');
%legend('No Islands','Islands','fontsize',20)
%legend('boxoff')
%set(gca,'fontsize',18);
%xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
%ylabel('Probability Density','fontsize',20,'interpreter','latex')
%%set(gca, 'xScale', 'log')
%box on