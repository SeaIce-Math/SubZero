paths
c2_boundary=initialize_boundaries_Nares();
Ly = max(c2_boundary(2,:));Lx = max(c2_boundary(1,:));
ratio=2/1;
fig = 0;
%ratio = abs(-1.5e5)/(Lx); %Ly/Lx;%
if (fig==0 || ~isvalid(fig))
    fig=figure('Position',[10 10 200 200*ratio],'visible','on');  
    set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
end
figure(fig)
clf(fig);

dn=1; % plot every dn'th velocity vector
% %quiver(ocean.Xo(1:dn:end),ocean.Yo(1:dn:end),ocean.Uocn(1:dn:end,1:dn:end),ocean.Vocn(1:dn:end,1:dn:end));
hold on;

%axis([ocean.Xo(1) ocean.Xo(end) ocean.Yo(1) ocean.Yo(end)]);

colormap('gray'); caxis([0 1]);

load('FloeStartIslandsPartial.mat','Floe','Nb');
for ii =1:length(Floe)
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
    Stress(ii) = max(abs(eig(Floe(ii).Stress)));
end

A = cat(1,Floe.area);

load('./plotting/NaresGLwide.mat'); load('./plotting/NaresCAwide.mat'); load('./plotting/NaresISwide.mat');% 
NaresIm2 = naresGLwide+naresCAwide+naresISwide;
[Ny,Nx,Nz] = size(NaresIm2);
NaresIm3 = ones(Ny,Nx,Nz,'uint8');
%NaresIm2 = naresISwide;
col = [10    18    29];
for ii = 1:3
    in1 = NaresIm2(:,:,ii); in1(in1==0)=col(ii);
    in2 = NaresIm3(:,:,ii)*col(ii);
    NaresIm2(:,:,ii) = [in1];  
    NaresIm3(:,:,ii) = [in2];  
end

image(xc,yc,NaresIm2)
set(gca, 'ydir', 'normal')
hold on; 
%image(xc,yc-4e5,NaresIm3)
plot([Floe(1+Nb:end).poly],'FaceColor',[184 194 195]/256,'FaceAlpha',1,'EdgeColor',[1 1 1]*0.3,'linewidth',0.3);

%hold on; 
%clear poly_bound
%for iii = 1:Nb
%    poly_bound(iii) = polyshape(Floe(iii).c_alpha'+[Floe(iii).Xi Floe(iii).Yi]);
%end
%plot(R,'FaceColor',[1 1 1],'FaceAlpha',0.5,'EdgeAlpha',0.5);
axis([-Lx Lx -Ly Ly])
%xlabel('m');ylabel('m');
set(gca,'Ydir','normal');
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca, 'position',[0 0 1 1])
box on
ylim([-3e5 1e5])

set(0, 'DefaultFigureRenderer', 'painters');
exportgraphics(fig,'Nares_wide.pdf' ,'resolution',300);
