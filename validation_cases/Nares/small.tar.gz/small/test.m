close all
fig = figure;
hold on


load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlt/Floe0000312.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
for ii =1:length(Floe)
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end
FloeAlt = Floe;
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlt2/Floe0000312.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
for ii =1:length(Floe)
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end
FloeAlt2 = Floe;
plot([FloeAlt.poly],'FaceColor',[1 1 1],'FaceAlpha',0.5,'EdgeAlpha',0.5); 
plot([FloeAlt2.poly],'FaceColor',[1 0 0],'FaceAlpha',0.5,'EdgeAlpha',0.5);

fig = figure(1);
exportgraphics(fig,['floes.jpg'] ,'resolution',300);