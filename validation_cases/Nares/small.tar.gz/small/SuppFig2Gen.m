close all
fig = figure;
hold on

%% Supp Fig 2a
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlpha0/Floe0000493.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux = A_total_flux+A_flux_tmp;
A_flux = A_flux-A_flux(3); A_flux(1) = 0;A_flux(2) = 0;
t = t_flux/24/3600;
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlt2/Floe0000493.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux3 = A_total_flux+A_flux_tmp;
A_flux3 = A_flux3-A_flux3(3); A_flux3(1) = 0;A_flux3(2) = 0;
t3 = t_flux/24/3600;
y = [A_flux(end) A_flux3(end)]/(t(end)*1e6);
X = categorical({'\beta = 0','\beta = -1/4'});
X = reordercats(X,{'\beta = 0','\beta = -1/4'});
bar(X,y)
%bh = bar(y);
%xticklabels({'0','\pi'})
set(gca,'fontsize',18);
ylabel('Mean Sea Ice Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
xlabel('Allowable Stress Scaling','fontsize',20,'interpreter','latex')
box on
exportgraphics(fig,['Supp2a.jpg']);

%% Supp Fig 2b
close all
fig = figure;
hold on
plot(t, A_flux/1e6)
plot(t3, A_flux3/1e6)
lgd = legend({'\beta=0' '\beta=-1/4'});
legend('boxoff')
legend('Location','northwest')
set(gca,'fontsize',18);
ylabel('Sea Ice Area Transported (km$^2$)','fontsize',20,'interpreter','latex')
xlabel('Time(days)','fontsize',20,'interpreter','latex')
exportgraphics(fig,['Supp2b.jpg']);


%% Supp Fig 2c
close all
fig = figure;
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlt2/Floe0000493.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux3 = A_total_flux+A_flux_tmp;
A_flux3 = A_flux3-A_flux3(3); A_flux3(1) = 0;A_flux3(2) = 0;
t3 = t_flux/24/3600;
bins = 0:250:3000;
tvals = 6900:100:length(t);
tvals3 = 6900:100:length(t3);
Transport1 = A_flux(tvals)/1e6; tdif = t(tvals(2))-t(tvals(1)); T1diff = Transport1(2:end)-Transport1(1:end-1); flux1 =T1diff/tdif;
Transport2 = A_flux3(tvals3)/1e6; tdif3 = t3(tvals3(2))-t3(tvals3(1)); T2diff = Transport2(2:end)-Transport2(1:end-1); flux2 =T2diff/tdif3;
h = histogram(flux1,bins,'FaceColor','r','Normalization','pdf');
hold on
h2 = histogram(flux2,bins,'FaceColor','b','Normalization','pdf');
lgd = legend({'\beta=0' '\beta=-1/4'});
fontsize(lgd,20,'points');
set(gca,'fontsize',18);
legend('box','off')
set(gca,'fontsize',18);
xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
ylabel('Probability Density','fontsize',20,'interpreter','latex')
box on
exportgraphics(fig,['Supp2c.jpg']);

