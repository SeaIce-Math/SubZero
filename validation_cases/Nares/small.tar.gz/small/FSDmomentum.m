%%Find FSDs

close all

y_low = [-2.5e5 0.5e5 0.5e5 -2.5e5];
x_low = [-1e5 -1e5 1e5 1e5];

for jj = 1:1
    lower_box = polyshape([x_low;y_low]');
    load(['/dat1/bpm5026/nares_momentum_new/Floe' num2str(jj,'%07.f') '.mat'],'Floe','Nb');
    FloeL = [];
    keep = zeros(1,length(Floe));
    for ii = 1+Nb:length(Floe)
        if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-2.5e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-0.5e5 
            FloeL = [FloeL Floe(ii)];
            keep(ii) = 1;
        end
    end

    %create boundary polyshape
    keep = logical(keep);
    FloeOut = Floe(~keep);
    clear poly
    for ii =1:length(FloeOut)
        poly(ii) = polyshape(FloeOut(ii).c_alpha'+[FloeOut(ii).Xi FloeOut(ii).Yi]);
    end

    for ii = 1:length(poly)
        lower_box = subtract(lower_box,poly(ii));
    end
    lower_box = rmholes(lower_box);
    %A_upper = area(upper_box); A_lower = area(lower_box);

    FloeLp = FloeL; clear FloeL; count = 1;
    for ii = 1:length(FloeLp)
        [in,~] = inpolygon(FloeLp(ii).c_alpha(1,:)'+FloeLp(ii).Xi,FloeLp(ii).c_alpha(2,:)'+FloeLp(ii).Yi,x_low, y_low);
        if sum(in)/length(in) == 1
            FloeL(count) = FloeLp(ii);
            count = count+1;
        end
    end

    clear polyL
    for ii =1:length(FloeL)
        polyL(ii) = polyshape(FloeL(ii).c_alpha'+[FloeL(ii).Xi FloeL(ii).Yi]);
    end

    edges = logspace( -1 , 1, 31 );
    bins = (edges(2:end)+edges(1:end-1))/2;

    Areas3 = cat(1,FloeL.area); %Find areas of segmented floes
    A_lower = sum(Areas3);
    a3 = sqrt(cat(1,Areas3));
    hFSD3 = histogram(a3/1e3,edges);
    edges3 = hFSD3.BinEdges;
    val3 = hFSD3.Values;
    clear FSDsmall
    clear FSDsmall2
    count3 = 1;
    %Loop through to find floe sizes per km^2
    for ii = 1:length(val3)
        FSDsmall(count3) = sum(val3(ii:end))/(A_lower)*1e6;
        % FSDsmall2(count3) = sum(val3(ii:end));
        count3 = count3+1;
    end
    save(['/dat1/bpm5026/nares_momentum_new/FSD' num2str(jj,'%07.f') '.mat'],'FSDsmall');
end

x1 = log10(bins); x1 = x1(15:26);
clear m
for ii = 1:493
    load(['/dat1/bpm5026/nares_momentum_new/FSD' num2str(ii,'%07.f') '.mat'],'FSDsmall');
    y1 = log10(FSDsmall);
    y1 = y1(15:26);
    f = fit(x1',y1','poly1');
    m(ii) = f.p1;
end
save('/dat1/bpm5026/nares_momentum_new/slopes.mat','m')
m_mom = m;

clear m
for ii = 1:493
    load(['/dat1/bpm5026/Paper2runs/nares_small/FloesAlpha0/FSD' num2str(ii,'%07.f') '.mat'],'FSDsmall');
    y1 = log10(FSDsmall);
    y1 = y1(15:26);
    f = fit(x1',y1','poly1');
    m(ii) = f.p1;
end
save('/dat1/bpm5026/Paper2runs/nares_small/FloesAlpha0/slopes.mat','m')

%%
%load('slopes_independent.mat','m'); msmall = m;
%load('m_small.mat','m')
close all
dt = 5; nDTOut = 350;
t = (0:492)*dt*nDTOut/24/3600;
plot(t,m_mom,'linewidth',2)
hold on
plot(t,m,'linewidth',2)
legend('New Collision','Old Collision','fontsize',24)
legend('boxoff')
set(gca,'fontsize',18);
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Exponent of Power Law','fontsize',20,'interpreter','latex')
fig = figure(1);
exportgraphics(fig,['ExponentEvolutionMom.jpg'] ,'resolution',300);