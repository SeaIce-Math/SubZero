close all
fig = figure;
hold on

load('obs_flux_may.mat')
T_flux = T_flux(14:end); i_flux = i_flux(14:end); 
%load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlt/Floe0000192.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
%A_flux2 = A_total_flux+A_flux_tmp;
%A_flux2 = A_flux2-A_flux2(3); A_flux2(1) = 0;A_flux2(2) = 0;
%t2 = t_flux/24/3600;
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlt2/Floe0000304.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux3 = A_total_flux+A_flux_tmp;
A_flux3 = A_flux3-A_flux3(3); A_flux3(1) = 0;A_flux3(2) = 0;
t3 = t_flux/24/3600;
load('/dat1/bpm5026/Paper2runs/nares_small/FloesAlpha0/Floe0000304.mat','Floe','Nb','A_total_flux','A_flux_tmp','M_total_flux','t_flux')
A_flux4 = A_total_flux+A_flux_tmp;
A_flux4 = A_flux4-A_flux4(3); A_flux4(1) = 0;A_flux4(2) = 0;
t4 = t_flux/24/3600;
i_flux_tot = 0; i_flux_tot2 = 0;
for kk = 2:length(i_flux)
    i_flux_tot(kk) = i_flux_tot(kk-1)+i_flux(kk)*(T_flux(kk)-T_flux(kk-1))*1e6;
    i_flux_tot2(kk) = trapz(T_flux(1:kk),i_flux(1:kk))*1e6;
end
rho_ice=920; h = mean(cat(1,Floe.h));
%plot(t2,(A_flux2-A_flux2(520))/1e6,'linewidth',2); hold on
plot(t3,(A_flux3-A_flux3(520))/1e6,'linewidth',2); hold on
plot(t4,(A_flux4-A_flux4(520))/1e6,'linewidth',2); hold on
plot(T_flux-T_flux(1),i_flux_tot2/1e6-300,'linewidth',2)
set(gca,'fontsize',16);
ylim([0 9000])
xlabel('Time (days)','fontsize',20,'interpreter','latex')
ylabel('Sea Ice Area Transported (km$^2$)','fontsize',20,'interpreter','latex')
xlim([0 t3(end)])
legend('SubZero-1/2','SubZero-0','Observations','fontsize',18)
legend('boxoff')
legend('Location','northwest')
fig = figure(1);
exportgraphics(fig,['flux.jpg'] ,'resolution',300);