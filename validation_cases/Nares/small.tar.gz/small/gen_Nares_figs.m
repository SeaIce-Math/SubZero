paths
set(0, 'DefaultFigureRenderer', 'painters');
c2_boundary=initialize_boundaries_Nares();


for ii =210:493
    clear fig; clear Floe; close all;
    load(['/dat1/bpm5026/nares_momentum_new/Floe' num2str(ii,'%07.f') '.mat'],'Floe','Nb');
    [fig] =plot_Nares_wide(Floe,c2_boundary,Nb);
    exportgraphics(fig,['/dat1/bpm5026/nares_momentum_new/' num2str(ii,'%03.f') '.jpg'] ,'resolution',300);
end


