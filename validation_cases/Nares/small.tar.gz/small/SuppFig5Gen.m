close all
fig = figure;
hold on

%% Supp Fig 5a
load('/dat1/bpm5026/Paper2runs/thickness_test/islands15/Floe0000226.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux = A_total_flux+A_flux_tmp;
A_flux = A_flux-A_flux(2); A_flux(1) = 0;
t = t_flux/24/3600;
load('/dat1/bpm5026/Paper2runs/thickness_test/islands15_t1/Floe0000226.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux1 = A_total_flux+A_flux_tmp;
A_flux1 = A_flux1-A_flux1(3); A_flux1(1) = 0;A_flux1(2) = 0;
t1 = t_flux/24/3600;
load('/dat1/bpm5026/Paper2runs/thickness_test/islands15_t2/Floe0000226.mat','Floe','Nb','A_total_flux','A_flux_tmp','t_flux')
A_flux2 = A_total_flux+A_flux_tmp;
A_flux2 = A_flux2-A_flux2(3); A_flux2(1) = 0;A_flux2(2) = 0;
t2 = t_flux/24/3600;
y = [A_flux(end)/t1(end) A_flux1(end)/t2(end) A_flux2(end)/t3(end)]/1e6;
X = categorical({'h = 0.5','h = 1', 'h = 1.5'});
X = reordercats(X,{'h = 0.5','h = 1', 'h = 1.5'});
bar(X,y)
set(gca,'fontsize',18);
ylabel('Mean Sea Ice Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
xlabel('Allowable Stress Scaling','fontsize',20,'interpreter','latex')
box on
exportgraphics(fig,['Supp5a.jpg']);



%% Supp Fig 5b
close all
fig = figure;
bins = 0:250:3000;
tvals = 400:100:length(t);
tvals1 = 200:100:length(t1);
tvals2 = 200:100:length(t2);
Transport = A_flux(tvals)/1e6; tdif = t(tvals(2))-t(tvals(1)); Tdiff = Transport(2:end)-Transport(1:end-1); flux =Tdiff/tdif;
Transport1 = A_flux1(tvals1)/1e6; tdif1 = t1(tvals1(2))-t1(tvals1(1)); T1diff = Transport1(2:end)-Transport1(1:end-1); flux1 =T1diff/tdif1;
Transport2 = A_flux2(tvals2)/1e6; tdif2 = t2(tvals2(2))-t2(tvals2(1)); T2diff = Transport2(2:end)-Transport2(1:end-1); flux2 =T2diff/tdif2;
h = histogram(flux,bins,'FaceColor','r','Normalization','pdf');
hold on
h2 = histogram(flux2,bins,'FaceColor','b','Normalization','pdf');
lgd = legend({'h=0.5 m' 'h=1.5'});
fontsize(lgd,20,'points');
set(gca,'fontsize',18);
legend('box','off')
set(gca,'fontsize',18);
xlabel('Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
ylabel('Probability Density','fontsize',20,'interpreter','latex')
box on
exportgraphics(fig,['Supp5b.jpg']);

%% Supp Fig 5c
close all
fig = figure;
plot(flux)
hold on
plot(flux1)
plot(flux2)
set(gca,'fontsize',18);
ylabel('Sea Ice Area Flux (km$^2$/day)','fontsize',20,'interpreter','latex')
exportgraphics(fig,['Supp5c.jpg']);
