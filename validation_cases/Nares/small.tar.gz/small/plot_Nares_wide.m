function [fig] =plot_Nares_wide(Floe,c2_boundary,Nb)
Ly = max(c2_boundary(2,:));Lx = max(c2_boundary(1,:));
ratio=2/1;
fig = 0;
if (fig==0 || ~isvalid(fig))
    fig=figure('Position',[10 10 200 200*ratio],'visible','on');  
    set(fig,'PaperSize',12*[1 ratio],'PaperPosition',12*[0 0 1 ratio]);
end
figure(fig)
clf(fig);

load('./plotting/NaresGLwide.mat'); load('./plotting/NaresCAwide.mat'); load('./plotting/NaresISwide.mat');% 
NaresIm2 = naresGLwide+naresCAwide+naresISwide;
[Ny,Nx,Nz] = size(NaresIm2);
NaresIm3 = ones(Ny,Nx,Nz,'uint8');
col = [10    18    29];
for ii = 1:3
    in1 = NaresIm2(:,:,ii); in1(in1==0)=col(ii);
    %in2 = NaresIm3(:,:,ii)*col(ii);
    NaresIm2(:,:,ii) = [in1];  
    %NaresIm3(:,:,ii) = [in2];  
end

image(xc,yc,NaresIm2)
set(gca, 'ydir', 'normal')
hold on; 
%image(xc,yc-4e5,NaresIm3)

for ii =1:length(Floe)
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end
plot([Floe(1+Nb:end).poly],'FaceColor',[184 194 195]/256,'FaceAlpha',1,'EdgeColor',[1 1 1]*0.3,'linewidth',0.3);

colormap('gray'); caxis([0 1]);
axis([-Lx Lx -Ly Ly])
%xlabel('m');ylabel('m');
set(gca,'Ydir','normal');
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca, 'position',[0 0 1 1])
box on
ylim([-3e5 1e5])

end