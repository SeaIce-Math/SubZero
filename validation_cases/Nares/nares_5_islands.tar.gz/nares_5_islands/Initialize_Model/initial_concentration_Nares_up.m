function [Floe, Nb] = initial_concentration_Nares_up(c2_boundary,target_concentration,height, NumFloes, min_floe_size,ISLANDS)
%% This function is used to generate the initial floe field

%Identify the grids to align with the concentrations specified by the input
[Ny, Nx] = size(target_concentration);
c = flipud(target_concentration);
x = min(c2_boundary(1,:)):(max(c2_boundary(1,:))-min(c2_boundary(1,:)))/Nx:max(c2_boundary(1,:));
y = min(c2_boundary(2,:)):(max(c2_boundary(2,:))-min(c2_boundary(2,:)))/Ny:max(c2_boundary(2,:));
c2_boundary_poly = polyshape(c2_boundary');
dx = x(2)-x(1);
dy = y(2)-y(1);
Lx = abs(min(x));Ly = abs(min(y));
Bx = [-Lx -Lx Lx    Lx];
By = [-Ly  -1.5e5 -1.5e5  -Ly];
B = polyshape(Bx',By');

%Create floes that act as boundaries and wont move
load( './Nares/poly_Nares_up','poly')
% polyout = sortregions(Nares,'area','ascend');
R = poly(1:2);

Floe = []; bound = c2_boundary_poly;
for ii = 1:length(R)
    FloeNEW = initialize_floe_values(R(ii),height);
    bound = subtract(bound, FloeNEW.poly);
    Floe = [Floe FloeNEW];
end
N = length(Floe);
for ii = 1:N
    Floe(ii).poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end

% Floes1=fracture_floe(Floe(N-2),10,Floe);
% Floes2=fracture_floe(Floe(N-1),10,Floe);
% Floes3=fracture_floe(Floe(N),10,Floe);
% Floes4=fracture_floe(Floe(N-3),3,Floe);
% Floes5=fracture_floe(Floe(N-4),3,Floe);
% FloeNEW = [Floes1 Floes2 Floes3 Floes4 Floes5];
% for ii = 1:length(FloeNEW)
%     FloeNEW(ii).poly = polyshape(FloeNEW(ii).c_alpha'+[FloeNEW(ii).Xi FloeNEW(ii).Yi]);
% end
% Floe = [Floe(1:N-5) FloeNEW];
Bu = union([Floe.poly]);
Bu = union(Bu,B);

poly(1:2) = [];

Nb = length(Floe);
%Loop through all the regions of the domain to create new floes
for jj = 1:Ny
    for ii = 1:Nx
        if c(jj,ii)>0
            polyout=subtract([poly],Bu);
            clear polyfloe; polyfloe = [];
            for kk = 1:length(polyout)
                R = regions(polyout(kk));
                polyfloe = [polyfloe; R];
            end
            polyIce = [];
            for count = 1:length(polyfloe)
                poly = polyfloe(count);
                R = regions(poly);
                for kk = 1:length(R)
                    if R(kk).NumHoles > 0
                        p = holes(R(kk));
                        if length(p)>1
                            xx = 1; xx(1) =[1 2];
                        end
                        for iii = 1:length(p)
                            pfull = rmholes(R(kk));
                            [Xi2,Yi2] = centroid(p);
                            L = [ Xi2 Yi2; Xi2+1 Yi2];
                            PcT = cutpolygon([pfull.Vertices; pfull.Vertices(1,:)], L, 1);
                            pnew = polyshape(PcT);
                            pnew = subtract(pnew,union(p));
                            PcB = cutpolygon([pfull.Vertices; pfull.Vertices(1,:)], L, 2);
                            pnew2 = polyshape(PcB);
                            pnew2 = subtract(pnew2,union(p));
                            poly = [regions(pnew); regions(pnew2)];
                        end
                    else
                        poly = R(kk);
                    end
                    polyIce = [polyIce; poly];
                end
            end
            Atot = 0;
            count = 1;

            Nf = 1:length(polyIce);%randperm(length(b));
            for count = 1:length(polyIce)
                    floenew = initialize_floe_values(polyIce(Nf(count)),height);
                    Floe = [Floe floenew];
                    Atot = Atot+floenew.area;
            end
        end
    end
end
areas = cat(1,Floe.area);
areas(1:Nb) = min_floe_size;
Floe(areas<min_floe_size)=[];
end

