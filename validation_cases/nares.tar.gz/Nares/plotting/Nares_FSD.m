function fig = Nares_FSD(Floe,c2_boundary,Nb)

%Split into above and below islands
FloeU = []; FloeL = [];
for ii = 1+Nb:length(Floe)
    if max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-6e4
        FloeL = [FloeL Floe(ii)];
    elseif min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-5e4
        FloeU = [FloeU Floe(ii)];
    end
end

%create boundary polyshape
for ii =1:Nb
    poly(ii) = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end
% for ii =1:length(FloeU)
%     polyU(ii) = polyshape(FloeU(ii).c_alpha'+[FloeU(ii).Xi FloeU(ii).Yi]);
% end
% for ii =1:length(FloeL)
%     polyL(ii) = polyshape(FloeL(ii).c_alpha'+[FloeL(ii).Xi FloeL(ii).Yi]);
% end
boundaries = union([poly]);

Ly_up = max(c2_boundary(2,:));
Ly_low = min(c2_boundary(2,:));
x = c2_boundary(1,:);
y_up = [-5e4 Ly_up Ly_up -5e4 -5e4];
y_low = [Ly_low -6e4 -6e4 Ly_low Ly_low];
upper_box = polyshape([x;y_up]');
lower_box = polyshape([x;y_low]');
upper_box = subtract(upper_box,boundaries);
lower_box = subtract(lower_box,boundaries);
A_upper = area(upper_box); A_lower = area(lower_box);
%% Find FSD before islands
close all
Areas = cat(1,FloeU.area); %Find areas of segmented floes
a = sqrt(cat(1,Areas));
hFSD = histogram(a/1e3);
edges = hFSD.BinEdges;
val = hFSD.Values;
clear FSD
count3 = 1;
%Loop through to find floe sizes per km^2
for ii = 1:length(val)
    FSD(count3) = sum(val(ii:end))/(A_upper)*1e6;
    count3 = count3+1;
end
%Plot FSD
bins = (edges(2:end)+edges(1:end-1))/2;
bins(FSD<1e-4) = []; FSD(FSD<1e-4) = [];
figure;
fig(1) = loglog(bins,FSD,'linewidth',2);
min_size = 1;
binsUpper = bins(bins>min_size); slopes1 = -2.25;
hold on
% fig(3) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
fig = figure(2);
% exportgraphics(fig,['FSD_Nares_upper.pdf'] ,'resolution',300);

%% Find FSD below islands
figure
Areas = cat(1,FloeL.area); %Find areas of segmented floes
a = sqrt(cat(1,Areas));
hFSD = histogram(a/1e3);
edges = hFSD.BinEdges;
val = hFSD.Values;
clear FSD
count3 = 1;
%Loop through to find floe sizes per km^2
for ii = 1:length(val)
    FSD(count3) = sum(val(ii:end))/(A_lower)*1e6;
    count3 = count3+1;
end
%Plot FSD
bins = (edges(2:end)+edges(1:end-1))/2;
bins(FSD<1e-4) = []; FSD(FSD<1e-4) = [];
figure(2);
fig(2) = loglog(bins,FSD,'linewidth',2);
min_size = 1;
binsUpper = bins(bins>min_size); slopes1 = -2.25;
% hold on
fig(3) = loglog([binsUpper(1) 50], 5*1e-1*[binsUpper(1) 50].^(slopes1),'k--','linewidth',2);
legend('Nares Entrance', 'Nares Exit','L^{-2.25}','fontsize',20)
legend boxoff
% set(gca, 'YScale', 'log')
% set(gca, 'xScale', 'log')
% xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
% ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
fig = figure(2);
% exportgraphics(fig,['FSD_Nares_lower.pdf'] ,'resolution',300);
end

