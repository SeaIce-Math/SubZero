function [Floe,Princ] = FracMohr(Floe,Nb,min_floe_size,concentration)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
        Pstar = 8.5e5; C = 20;
        concentration = 1;
        h = mean(cat(1,Floe.h));
        P = Pstar*h*exp(-C*(1-concentration));
        t = linspace(0,2*pi) ;
        a = P*sqrt(2)/2 ; b = a/2 ;
        x = a*cos(t) ;
        y = b*sin(t) ;
        Mohr = polyshape(x,y);
%         Mohr = translate(Mohr, [100, 100]);
       Mohr = rotate(Mohr,45);
       Mohr = translate(Mohr,[-P/2, -P/2]);
        A = cat(1,Floe.area);
%        q = 5.2; SigC = 250e3;
%        Sig1 = (1/q+1)*SigC/(1/q-q);
%        Sig2 = q*Sig1+SigC;
%        Sig11 = 1e8;
%        Sig22 = q*Sig11+SigC;
%        MohrX = [Sig1; Sig11; Sig22];
%        MohrY = [Sig2; Sig22; Sig11];
        %MohrX = [Sig1; Sig11; Sig22]*0.45;*1.1
        %MohrY = [Sig2; Sig22; Sig11]*0.45;
%        Mohr = polyshape(MohrX,MohrY);
q = 5.2; SigC = 250e3;
Sig1 = (1/q+1)*SigC/(1/q-q);
Sig2 = q*Sig1+SigC;
Sig11 = 1.5e5;
Sig22 = q*Sig11+SigC;
MohrX = [Sig1; Sig11; Sig22];
MohrY = [Sig2; Sig22; Sig11];
Mohr = polyshape(-MohrX,-MohrY);
        p1 = -59520; p2 = 4e8;
        for ii = 1:length(Floe)
            Stress = eig(Floe(ii).Stress);
            Princ1(ii) = max(Stress); Princ2(ii) = min(Stress); 
            Princ(ii,1) = max(Stress);
            Princ(ii,2) = min(Stress);
            Princ(ii,3) = Floe(ii).area;
            Stresses(ii) = vecnorm([Princ1 Princ2]);
%            Stresses(ii) = vecnorm([Princ(ii,1:2)]);
        end
        Princ1 = Princ(:,1); Princ2 = Princ(:,2); 
        %[d_min, ~, ~] = p_poly_dist(Princ1, Princ2, Mohr.Vertices(:,1), Mohr.Vertices(:,2),true);
        [in,out] = inpolygon(Princ1,Princ2,Mohr.Vertices(:,1), Mohr.Vertices(:,2));
%         [~,x_d_min, y_d_min] = p_poly_dist(Princ1, Princ2,Mohr.Vertices(:,1), Mohr.Vertices(:,2),true);
%         [d_min2] = p_poly_dist(Princ1, Princ2,[p1; p2], [p1; p2],false);
%         [d_min3] = p_poly_dist(x_d_min, y_d_min,[p1; p2], [p1; p2],false);
        
%         xx = 1; xx(1) =[1 2];
        %keep=rand(length(Floe),1)>d_min;
%         keep=rand(length(Floe),1)>0.1*(d_min2./d_min3).^2;
        p = rand(length(Floe),1);
        StressNorm = Stresses/max(Stresses);%rmoutliers(Stresses));
%        in(p>StressNorm'/2) = 1;
        keep = zeros(length(Floe),1);
        keep(in) = 1;
        keep(A<min_floe_size)=1;
        keep(1:Nb) = ones(Nb,1);
        keep = logical(keep);
        for ii = 1:length(Floe)
            FracFloes(ii).floenew = [];
        end
        parfor ii = 1:length(keep)
            if ~keep(ii)
                FracFloes(ii).floenew=fracture_floe(Floe(ii),7,Floe);
            end
        end
        fracturedFloes =[];
        for ii = 1:length(FracFloes)
            fracturedFloes = [fracturedFloes FracFloes(ii).floenew];
        end
        if isfield(fracturedFloes,'potentialInteractions')
            fracturedFloes=rmfield(fracturedFloes,{'potentialInteractions'});
        end
        if ~isempty(fracturedFloes)
%            save('FloeOld.mat','Floe')
 %           xx = 1; xx(1) =[1 2];
            Floe=[Floe(keep) fracturedFloes];
        end

end

