function paths
%Sets all the paths needed to run SubZero
addpath('./Initialize_Model') 
addpath('./collisions') 
addpath('./plotting') 
addpath('./polygon_operations') 
addpath('./Physcial_Processes') 
addpath('./clipper_ver6.4.2') 
end

