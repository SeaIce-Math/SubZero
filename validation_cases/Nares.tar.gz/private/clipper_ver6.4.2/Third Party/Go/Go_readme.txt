An AS3 Flash port written by Chris Tessum:
https://github.com/ctessum/go.clipper
