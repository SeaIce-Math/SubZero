jj = 1499;
load(['./Floes2/Floe' num2str(jj,'%07.f') '.mat'])
a = sqrt(cat(1,Floe(Nb+1:end).area));
hFSD = histogram(a/1e3);
edges = hFSD.BinEdges;
masstot = 0;
Lx=2e5; Ly=1e6; 
x=[-1 -1 1 1 -1]*Lx/2; 
y=[-1 1 1 -1 -1]*Ly/2;
y2 = y; y2(2) = 1e5; y2(3) = 1e5;
clear poly
for ii =1:Nb
    poly(ii) = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
end
c2_boundary = [x; y]; c2_boundary2 = [x; y2];
c2_boundary_poly = polyshape(c2_boundary');
c2_boundary_poly2 = polyshape(c2_boundary2');
pbound = intersect(c2_boundary_poly,union([poly]));
pbound2 = intersect(c2_boundary_poly2,union(poly(1),poly(2)));
Atot = subtract(c2_boundary_poly,pbound);
Atot2 = subtract(c2_boundary_poly2,pbound2);
Atotal = area(Atot);Atotal2 = area(Atot2);
jj = 1;poly
load(['./Floes2/Floe' num2str(jj,'%07.f') '.mat'])
a_total = sum(cat(1,Floe.area));
for jj = 1:1499
     load(['./Floes2/Floe' num2str(jj,'%07.f') '.mat'])
    a = sqrt(cat(1,Floe(Nb+1:end).area));
    hFSD = histogram(a/1e3,edges);
    val = hFSD.Values;
    clear FSD
    count3 = 1;
    for ii = 1:length(val)
        FSD(count3) = sum(val(ii:end))/(Atotal)*1e6;
        count3 = count3+1;
    end
    save(['./Floes2/FSD' num2str(jj,'%07.f') '.mat'],'val','FSD')
    NumFloes(jj) = length(Floe);
    
    close all
    y = cat(1,Floe(Nb+1:end).Yi);
    a = a(y<5e4);
    hFSD = histogram(a/1e3,edges);
    val2 = hFSD.Values;
    clear FSD2
    count3 = 1;
    for ii = 1:length(val2)
        FSD2(count3) = sum(val2(ii:end))/(Atotal2)*1e6;
        count3 = count3+1;
    end
    save(['./Floes2/FSD2' num2str(jj,'%07.f') '.mat'],'val2','FSD2')
end

%% Find Average FSDs
Time = (0:1498)*10*150/3600/24;
day = 1:29:length(Time);
days = [0:(length(day)-1)]*0.5;
close all 
 
bins = (edges(2:end)+edges(1:end-1))/2;
clear slopes
% fig=figure(1);
% fig2 = figure(2);
for ii = 1:length(day)
    FSDav = 0; FSD2av = 0; 
    if ii ==length(day)
        for jj = day(ii):length(Time)
            load(['./Floes2/FSD' num2str(ii,'%07.f') '.mat'])
            load(['./Floes2/FSD2' num2str(ii,'%07.f') '.mat'])
            FSDav = FSDav + FSD/(length(Time)+1-day(ii));
            FSD2av = FSD2av + FSD2/(length(Time)+1-day(ii));
        end
    else
        for jj = day(ii):day(ii+1)
            load(['./Floes2/FSD' num2str(ii,'%07.f') '.mat'])
            load(['./Floes2/FSD2' num2str(ii,'%07.f') '.mat'])
            FSDav = FSDav + FSD/(day(ii+1)-day(ii));
            FSD2av = FSD2av + FSD2/(day(ii+1)-day(ii));
        end
    end
%     fig(1) = loglog(bins,FSD2av,'linewidth',2);
    bnow = bins(FSD2av>0); FSD2av = FSD2av(FSD2av>0);
    Bp = polyfit(log10(bnow(2:end)), log10(FSD2av(2:end)), 1);
    slopes(ii) = Bp(1);
    save(['./Floes2/FSDave' num2str(ii,'%07.f') '.mat'],'FSDav','FSD2av','Bp','bnow')
end
% figure(1)
% fig(1) = loglog(bins,FSD,'linewidth',2);%(log10(bins(val>0)), log10(val(val>0)), 1)
% hold on
% figure(2)
hold on
fig(1) = loglog(bnow,FSD2av,'linewidth',2);%(log10(bins(val>0)), log10(val(val>0)), 1)
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')
%% Stresses
close all
Lx=1e5; Ly=1e5; 
min_floe_size = 4*Lx*Ly/20000; min_size = sqrt(min_floe_size)/1000;

jj = 999;
load(['./Floes2/Floe' num2str(jj,'%07.f') '.mat'])
figure
Pstar = 1e5; C = 20; concentration = 1;
h = mean(cat(1,Floe.h));
P = Pstar*h*exp(-C*(1-concentration));
t = linspace(0,2*pi) ;
a = P*sqrt(2)/2 ; b = a/2 ;
x = a*cos(t) ;
y = b*sin(t) ;
Mohr = polyshape(x,y);
Mohr = rotate(Mohr,45);
Mohr = translate(Mohr,[-P/2, -P/2]);

%Calculate Principal Stresses
% Floe=Floe(Nb+1:end);
clear Princ1;clear Princ2; clear Princ
for ii = 1:length(Floe)
    Stress = eig(Floe(ii).Stress);
    Princ(ii,1) = max(Stress);
    Princ(ii,2) = min(Stress);
    Princ(ii,3) = Floe(ii).area;
end
Princ1 = Princ(:,1); Princ2 = Princ(:,2);
% xx = 1; xx(1) =[1 2];
%Determine if stresses are inside or outside allowable regions
[in,~] = inpolygon(Princ1,Princ2,Mohr.Vertices(:,1), Mohr.Vertices(:,2));
keep = zeros(length(Floe),1);
keep(in) = 1;
keep(A<min_floe_size)=1;
keep(1:Nb) = ones(Nb,1);
keep = logical(keep);
FloeArea =sqrt(cat(1,Floe.area))/1000; FloeArea(1:Nb) = 0.1;

close all
figure('Position', [100, 100, 900, 900]);
axes
axis('equal')
subplot(2,2,1)
scatter(Princ1(in),Princ2(in),FloeArea(in),'bo','MarkerFaceAlpha',0.6,'MarkerEdgeAlpha',0.6)
hold on
scatter(Princ1(~in),Princ2(~in),FloeArea(~in),'ro','MarkerFaceAlpha',0.6,'MarkerEdgeAlpha',0.6)
% plot(-Princ1(~in),-Princ2(~in),'rx','linewidth',2)
plot(Mohr,'facecolor','none','LineStyle','--','linewidth',2)
scatter(Princ2(in),Princ1(in),FloeArea(in),'bo','MarkerFaceAlpha',0.6,'MarkerEdgeAlpha',0.6)
scatter(Princ2(~in),Princ1(~in),FloeArea(~in),'ro','MarkerFaceAlpha',0.6,'MarkerEdgeAlpha',0.6)
% plot(-Princ2(in),-Princ1(in),'bo')
% plot(-Princ2(~in),-Princ1(~in),'rx','linewidth',2)
legend({'Not Fractured Floes','Fractured Floes','Mohrs Cone'},'fontsize',14)
legend boxoff
axis equal
box
xlim([-10e4 2e4])
ylim([-10e4 2e4])
set(gca,'fontsize',18);
yticks([-1e5, -5e4, 0])
xticks([-1e5, -5e4, 0])
xlabel('$\sigma_1$ (Pa)','fontsize',24,'interpreter','latex')
ylabel('$\sigma_2$ (Pa)','fontsize',24,'interpreter','latex')
set(0, 'DefaultFigureRenderer', 'painters');
%fig = figure(1);
%exportgraphics(fig,['./FloesS3/figs/Stresses.pdf'] ,'resolution',300);
    
%% Plot time evolution of number of floes/FSD

subplot(2,2,2)
figure(1)
yyaxis left
plot(Time,NumFloes,'linewidth',2)
yyaxis right
plot(days,slopes,'linewidth',2)
set(gca,'fontsize',18);
box on
xlabel('Time (days)','fontsize',24,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',24,'interpreter','latex')
yyaxis left
ylabel({'Number of Floes'},'fontsize',24,'interpreter','latex')
xlim([0 25])

%% Plot FSD averages

h1 = subplot(2,2,3);
cla(h1);
for ii = 1:10:length(day)
    hold on
    load(['./Floes2/FSDave' num2str(ii,'%07.f') '.mat'],'FSDav','FSD2av','Bp','bnow')
    fig(1) = loglog(bnow,FSD2av,'linewidth',2);%(log10(bins(val>0)), log10(val(val>0)), 1)
end
set(gca, 'YScale', 'log')
set(gca, 'xScale', 'log')


subplot(2,2,3)
binsUpper = bins; slopes2 = -2;%Bp(1);
fig2(4) = loglog([4.5 binsUpper(end)], 10*1e-2*[4.5 binsUpper(end)].^(slopes2),'k--','linewidth',2);

ylim([10e-6 0.01]); xlim([1 100])
set(gca,'fontsize',18);
box on
xlabel('Floe Size (km)','fontsize',20,'interpreter','latex')
ylabel({'FSD (floes per km$^2$)'},'fontsize',20,'interpreter','latex')
xticks([1, 1e1, 1e2])
legend('Day 1', 'Day 5','Day 10','Day 15','Day 20','Day 25','L^{-2}')
legend boxoff

%% 
ii = 998;
load(['./Floes2/Floe' num2str(ii,'%07.f') '.mat'],'t_flux','M_total_flux','A_total_flux')
A_flux = A_total_flux; A_flux(1) = 0;
A_flux(2:end) = A_total_flux(2:end)-A_total_flux(1:end-1);
t = t_flux/24/3600;
rho_ice=920;
h1 = subplot(2,2,4);
cla(h1);
yyaxis left
plot(t,M_total_flux,'linewidth',2.25)
set(gca,'fontsize',18);
ylabel('Mass (kg)','fontsize',16)
hold on
yyaxis right
n = 2;
hline = plot(t,A_flux*100/(1e6*3600*24),'linewidth',1.75);
for i=1:length(hline)
    hline(i).Color = [hline(i).Color 0.3];  % alpha=0.1
end
ylabel('Area Flux (10^3 km^2/day)','fontsize',16)
xlabel('Time (days)','fontsize',16)
xlim([0 15])
box on

set(0, 'DefaultFigureRenderer', 'painters');
fig = figure(1);
exportgraphics(fig,['./figs2/NaresValidation.pdf'] ,'resolution',300);
% % %% 
% % count = 1; 
% % areas = []; P1 = []; P2 = [];
% % newday = fix(Time(2:end))-fix(Time(1:end-1));
% % days = zeros(1,length(newday)+1);
% % days(2:end)  = newday;
% % days(1) = 1; days = logical(days);
% % for jj = 1:178
% %     if days(jj)
% %         save(['./NaresValidation/Stresses' num2str(count,'%07.f') '.mat'],'areas','P1','P2');
% %         count = count+1;
% %         areas = [];
% %         P1 = [];
% %         P2 = [];
% %     end
% %     
% %     load(['./NaresValidation/Floe' num2str(jj,'%07.f') '.mat'])
% %     Floe = Floe(3:end);
% %     y = cat(1,Floe.Yi);
% %     Floe(y>1e5)=[];
% %     a = sqrt(cat(1,Floe.area));
% %     areas = [areas; a];
% %     
% %     clear Princ1; clear Princ2
% %     for ii = 1:length(Floe)
% %         Stress = eig(Floe(ii).Stress);
% %         Princ1(ii,1) = max(Stress);
% %         Princ2(ii,1) = min(Stress);
% %     end
% %     
% %     P1 = [P1; Princ1];
% %     P2 = [P2; Princ2];
% % end
% % save(['./NaresValidation/Stresses' num2str(count,'%07.f') '.mat'],'areas','P1','P2');
% % %% 
% % 
% % subplot(2,2,1)
% % hold off
% % % Lx=1e5; Ly=1e5; 
% % % min_floe_size = 4*Lx*Ly/20000; min_size = sqrt(min_floe_size)/1000;
% % Pstar = 2.25e5; C = 20; concentration = 0.95;
% % h = 2;%mean(cat(1,Floe.h));
% % P = Pstar*h*exp(-C*(1-concentration));
% % t = linspace(0,2*pi) ;
% % a = P*sqrt(2)/2 ; b = a/2 ;
% % x = a*cos(t) ;
% % y = b*sin(t) ;
% % Mohr = polyshape(x,y);
% % Mohr = rotate(Mohr,45);
% % Mohr = translate(Mohr,[-P/2, -P/2]);
% % Mohr.Vertices = Mohr.Vertices;
% % count3 = 1;
% % ii = 28;
% % Princ1 = [];
% % Princ2 = [];
% % FloeArea = [];
% % jj = 7;
% % % for jj = 0:8
% %     load(['./NaresValidation/Stresses' num2str(jj,'%07.f') '.mat'])
% %     FloeArea = [FloeArea; areas/1000];
% %     Princ1 = [Princ1; P1];
% %     Princ2 = [Princ2; P2];
% % % end
% % % Princ1(FloeArea<min_size) = []; Princ2(FloeArea<min_size) = [];
% % % FloeArea(FloeArea<min_size) = [];
% % Amax = max(FloeArea);
% % [in,out] = inpolygon(Princ1,Princ2,Mohr.Vertices(:,1), Mohr.Vertices(:,2));
% % scatter(Princ1(in),Princ2(in),4*FloeArea(in),'bo','MarkerFaceAlpha',0.4,'MarkerEdgeAlpha',0.4)
% % hold on
% % scatter(Princ1(~in),Princ2(~in),4*FloeArea(~in),'ro','MarkerFaceAlpha',0.6,'MarkerEdgeAlpha',0.6)
% % % plot(-Princ1(~in),-Princ2(~in),'rx','linewidth',2)
% % plot(Mohr,'facecolor','none','LineStyle','--','linewidth',2)
% % scatter(Princ2(in),Princ1(in),4*FloeArea(in),'bo','MarkerFaceAlpha',0.4,'MarkerEdgeAlpha',0.4)
% % scatter(Princ2(~in),Princ1(~in),4*FloeArea(~in),'ro','MarkerFaceAlpha',0.6,'MarkerEdgeAlpha',0.6)
% % % plot(-Princ2(in),-Princ1(in),'bo')
% % % plot(-Princ2(~in),-Princ1(~in),'rx','linewidth',2)
% % legend({'Not Fractured Floes','Fractured Floes','Hibler Ellipse'},'fontsize',12)
% % legend boxoff
% % axis equal
% % box on
% % xlim([-1.5e5 0.5e5])
% % ylim([-1.5e5 0.5e5])
% % set(gca,'fontsize',18);
% % yticks([-1.5e5, -1e5, -0.5e5 0, 0.5e5])
% % xlabel('$\sigma_1$ (Pa)','fontsize',24,'interpreter','latex')
% % ylabel('$\sigma_2$ (Pa)','fontsize',24,'interpreter','latex')
% % set(0, 'DefaultFigureRenderer', 'painters');
% % fig = figure(1);
% % % exportgraphics(fig,['./NaresValidation/figs/Nares.pdf'] ,'resolution',300);
% % 
% % %% 
% % fig = 0;
% % for ii = 1:37*4
% %     load(['./FloesS3/Cheyenne/FloesS1/Floe' num2str(ii,'%07.f') '.mat'])
% %     clear poly
% %     for jj =1:length(Floe)
% %         poly(jj) = polyshape(Floe(jj).c_alpha'+[Floe(jj).Xi Floe(jj).Yi]);
% %     end
% %     figure(1)
% %     plot(poly,'FaceColor','k','FaceAlpha',0.3,'EdgeColor',[1 1 1]*0.2);
% %     fig = figure(1);
% %     exportgraphics(fig,['./FloesS3/Cheyenne/figs/' num2str(ii,'%03.f') '.jpg'] ,'resolution',300);
% % end
% % count = 1;
% % for ii = 47:97
% %     copyfile(['./FloesS3/areas' num2str(ii,'%07.f') '.mat'], ['./FloesS3/areas' num2str(count,'%07.f') '.mat']);
% %     copyfile(['./FloesS3/thickness' num2str(ii,'%07.f') '.mat'], ['./FloesS3/thickness' num2str(count,'%07.f') '.mat']);
% %     count = count+1;
% % end
% % 
% % for ii = 1:37
% %     copyfile(['./FloesS3/Cheyenne/new/FloesS3/Floe' num2str(ii,'%07.f') '.mat'], ['./FloesS3/Cheyenne/new/Floe' num2str(ii+37*3,'%07.f') '.mat']);
% % %     load(['./FloesS4/Floe' num2str(ii,'%07.f') '.mat'])
% % %     numfloe(37+ii) = length(Floe);
% % end
% % for ii = 1:37
% %     copyfile(['./FloesS3/Cheyenne/new/Floe' num2str(ii,'%07.f') '.mat'], ['./FloesS3/Floe' num2str(ii+2912,'%07.f') '.mat']);
% % %     load(['./FloesS4/Floe' num2str(ii,'%07.f') '.mat'])
% % %     numfloe(37+ii) = length(Floe);
% % end
% % plot(numfloe)
% % 
% % Nx = 1; Ny = 1; Nb = 2;Nout = 385;
% % x = [-100000 -100000 100000 100000];
% % y = [-100000 100000 100000 -100000];
% % Time = (0:Nout-1)*10*35; fig = 0;
% % c2_boundary_piston = polyshape([x;y]');
% % close all
% % clear Princ1
% % for ii = 1:Nout
% %     load(['./FloesCom1/Floe' num2str(ii,'%07.f') '.mat'])
% %     [eularian_data] = calc_eulerian_stress2(Floe,Nx,Ny,Nb,c2_boundary,dt,PERIODIC);
% %     Stress = [eularian_data.stressxx eularian_data.stressxy;eularian_data.stressxy eularian_data.stressyy];
% %     Stresses = eig(Stress);
% %     Princ1(ii) = max(-Stresses);
% %     clear poly
% %     for jj =1:length(Floe)
% %         poly(jj) = polyshape(Floe(jj).c_alpha'+[Floe(jj).Xi Floe(jj).Yi]);
% %     end
% %     plot(poly,'FaceColor','k','FaceAlpha',0.3,'EdgeColor',[1 1 1]*0.2);
% %     fig = figure(1);
% %     ylim([-100000 100000])
% %     xlim([-100000 100000])
% %     %     [fig] = plot_basic(fig, Time,Floe,ocean,c2_boundary_piston,Nb,PERIODIC);
% %     exportgraphics(fig,['./FloesCom1/figs/' num2str(ii,'%03.f') '.jpg'] ,'resolution',300);
% % end
% % 
% % clear poly
% % for ii = 1:length(x)
% %     xx = x{ii}; yy = y{ii};
% %     poly(ii) = polyshape(xx,yy);
% % end
% % 
% % figure
% % plot(Time,Princ1(1:Nout)/1e6,'linewidth',2)