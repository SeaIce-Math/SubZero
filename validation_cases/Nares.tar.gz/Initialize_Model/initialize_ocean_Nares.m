function [ocean, heat_flux, h0]=initialize_ocean_Nares(dt,nDTOut)

% defining ocean currents
ocean.fCoriolis=1.4e-4; % Coriolis parameter.

ocean.U = 0;

ocean.turn_angle=15*pi/180; % turning angle between the stress and surface current due to the Ekman spiral; the angle is positive!

% ocean grid;
dXo=20000; % in meters

Lx=2e6; Ly=2e6;
Xo=-1.5*Lx/2:dXo:1.5*Lx/2; Yo=-1.5*Ly/2:dXo:1.5*Ly/2; 
[Xocn, Yocn]=meshgrid(Xo,Yo);

%calculating ocean velocity field 
Uocn=zeros(size(Xocn)); Vocn=-0*ones(size(Xocn));

ocean.Xo=Xo;
ocean.Yo=Yo;
ocean.Uocn=Uocn;
ocean.Vocn=Vocn;
ocean.Xocn = Xocn; 
ocean.Yocn = Yocn;
ocean.Uocn_p=Uocn;
ocean.Vocn_p=Vocn;

%Calculate heat flux and how much ice would grow between creation of new
%floes
k = 2.14; %Watts/(meters Kelvin)
dt = 10; %seconds
Ta = -20; %Kelvin
To = 0; %Kelvin
rho_ice = 920; %kg/m^3
L = 2.93e5; % Joules/kg

h0 = real(sqrt(2*k*dt*nDTOut*(To-Ta)/(rho_ice*L)));
heat_flux = k*(Ta-To)/(rho_ice*L);
h0 = mean(h0(:)); %Thickness of newly created sea ice;

end