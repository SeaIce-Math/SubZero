function [Floe,dissolvedNEW] = floe_interactions_all(Floe, floebound, ubound, ucell, ocean, winds,c2_boundary, dt, HFo, min_floe_size, Nx,Ny,Nb, dissolvedNEW,doInt,COLLISION, PERIODIC, RIDGING, RAFTING)

id ='MATLAB:polyshape:repairedBySimplify';
warning('off',id)
id3 ='MATLAB:polyshape:boundary3Points';
warning('off',id3)
rho_ice=920;
global Modulus
if isempty(Modulus)
    xx = 1;
    xx(1) =[1 2];
end

save('FloeFail.mat','Floe');

Floe0 = Floe;

Lx= max(c2_boundary(1,:));
Ly= max(c2_boundary(2,:));
height.mean = 1; height.delta = 0;
c2_boundary_poly = polyshape(c2_boundary');
FloeB = initialize_floe_values(c2_boundary_poly, height);
live = cat(1,Floe.alive);
Floe(live==0)=[];
%Floe(i).interactions=[floeNumber Fx Fy px py torque];
%Floe(i).potentialInteractions(j).floeNum
%Floe(i).potentialInteractions(j).c_alpha=Floe(floeNum).c_alpha.

% for ii = 1+Nb:length(Floe)
%     h1 = Floe(ii).mass/(Floe(ii).area*rho_ice);
%     if abs(Floe(ii).h -h1) > 0.05
%         xx = 1;
%         xx(1) = [1 2];
%     end
% end

N0=length(Floe);
if PERIODIC
    
    ghostFloeX=[];
    ghostFloeY=[];
    parent=[];
    translation = [];
    
    x=cat(1,Floe.Xi);
    y=cat(1,Floe.Yi);
    alive=cat(1,Floe.alive);
    
    for i=1:length(Floe)
        poly = polyshape(Floe(i).c_alpha'+[x(i) y(i)]);
        %   if alive(i) && (x(i)>Lx-rmax(i)) || (x(i)<-Lx+rmax(i))
        if alive(i) && (max(abs(poly.Vertices(:,1)))>Lx)
            
            ghostFloeX=[ghostFloeX  Floe(i)];
            ghostFloeX(end).Xi=Floe(i).Xi-2*Lx*sign(x(i));
            parent=[parent  i];
            translation = [translation; -2*Lx*sign(x(i)) 0];
            
        end
        
        
    end
    
    Floe=[Floe ghostFloeX];
    
    x=cat(1,Floe.Xi);
    y=cat(1,Floe.Yi);
    alive=cat(1,Floe.alive);
    
    for i=1:length(Floe)
        poly = polyshape(Floe(i).c_alpha'+[x(i) y(i)]);
        %   if alive(i) && (x(i)>Lx-rmax(i)) || (x(i)<-Lx+rmax(i))
        if alive(i) && (max(abs(poly.Vertices(:,2)))>Ly)
            
            ghostFloeY=[ghostFloeY  Floe(i)];
            ghostFloeY(end).Yi=Floe(i).Yi-2*Ly*sign(y(i));
            parent=[parent  i];
            translation = [translation; 0 -2*Ly*sign(y(i))];

        end
        
    end
    
    Floe=[Floe ghostFloeY];
    
end

%Find length of new Floe variable including the ghost floes
N=length(Floe);
x=cat(1,Floe.Xi);
y=cat(1,Floe.Yi);
rmax=cat(1,Floe.rmax);
alive=cat(1,Floe.alive);
% if sum(alive)<2
%     xx = 1; xx(1)=[1 2];
% end

for i=1+Nb:N  %do interactions with boundary in a separate parfor loop
    
    Floe(i).interactions=[];
    
    Floe(i).OverlapArea = 0;
    
    Floe(i).potentialInteractions=[];
    
    Floe(i).collision_force=[0 0];
    
    Floe(i).Stress=zeros(2);
    
    Floe(i).collision_torque=0;
    
    k=1;
    
%     if abs(Floe(i).area/area(polyshape(Floe(i).c_alpha'))-1)>1e-3
%         xx = 1;
%         xx(1) =[1 2];
%     end
    
    if ( alive(i) && ~isnan(x(i)) ) && COLLISION
        for j=1:N
            %display(j);
            if j>i && alive(j) && sqrt((x(i)-x(j))^2 + (y(i)-y(j))^2)<(rmax(i)+rmax(j)) % if floes are potentially overlapping
                Floe(i).potentialInteractions(k).floeNum=j;
                Floe(i).potentialInteractions(k).c=[Floe(j).c_alpha(1,:)+x(j); Floe(j).c_alpha(2,:)+y(j)];
                Floe(i).potentialInteractions(k).Ui=Floe(j).Ui;
                Floe(i).potentialInteractions(k).Vi=Floe(j).Vi;
                Floe(i).potentialInteractions(k).h=Floe(j).h;
                Floe(i).potentialInteractions(k).area=Floe(j).area;
                Floe(i).potentialInteractions(k).Xi=x(j);
                Floe(i).potentialInteractions(k).Yi=y(j);
                Floe(i).potentialInteractions(k).ksi_ice = Floe(j).ksi_ice;
                k=k+1;
            end
            
        end
        
    end
end
% xx = 1; xx(1) =[1 2]
weld = zeros(length(Floe),1);
kill = zeros(1,N0); transfer = kill;
% tic
%for i=1+Nb:N  %now the interactions could be calculated in a parfor loop!
parfor i=1+Nb:N  %now the interactions could be calculated in a parfor loop!
        
    c1=[Floe(i).c_alpha(1,:)+x(i); Floe(i).c_alpha(2,:)+y(i)];
    if ~isempty(Floe(i).potentialInteractions)
        
        for k=1:length(Floe(i).potentialInteractions)
            
            floeNum=Floe(i).potentialInteractions(k).floeNum;
            c2=Floe(i).potentialInteractions(k).c;
            
            %[force_j,P_j, overlap] = floe_interactions(c1,c2,c2_boundary,PERIODIC);
%             [force_j,P_j, overlap] = floe_interactions_old(c1,c2,c2_boundary,PERIODIC);
%             [force_j,P_j, overlap] = floe_interactions_poly2(Floe(i),Floe(i).potentialInteractions(k));
            [force_j,P_j, overlap] = floe_interactions_poly_con2(Floe(i),Floe(i).potentialInteractions(k),c2_boundary,PERIODIC,Modulus,dt);
            %if ~worked, disp(['contact points issue for (' num2str(i) ',' num2str(floeNum) ')' ]); end
            
            if sum(abs(force_j(:)))~=0
                Floe(i).interactions=[Floe(i).interactions ; floeNum*ones(size(force_j,1),1) force_j P_j zeros(size(force_j,1),1) overlap'];
                Floe(i).OverlapArea = sum(overlap)+Floe(i).OverlapArea;
            elseif isinf(overlap)
                if i <= N0 && sign(overlap)>0
                    kill(i) = i;%floeNum;
                    transfer(i)=floeNum;
                    %if Floe(i).area > 5e6
                    %    save('FloeKill.mat','Floe','i','floeNum','c2_boundary','PERIODIC','Modulus','dt')
                    %    xx = 1; xx(1) =[1 2];
                    %end
                elseif floeNum <= N0
                    kill(i) = floeNum;
                    %if Floe(i).potentialInteractions(k).area > 5e6
                    %    save('FloeKill.mat','Floe','i','floeNum','c2_boundary','PERIODIC','Modulus','dt')
                        %transfer(floeNum) = i;
                    %    xx = 1; xx(1) =[1 2];
                    %end
                end
            end
            
        end
        
    end
    if ~PERIODIC
%         c1=[Floe(i).c_alpha(1,:)+x(i); Floe(i).c_alpha(2,:)+y(i)];
        [force_b, P_j, overlap] = floe_interactions_poly_con2(Floe(i), floebound,c2_boundary,PERIODIC,Modulus,dt);
%         [force_b, P_j, overlap] = floe_interactions_bound(c1, c2_boundary,c2_boundary,PERIODIC);
        in = inpolygon(x(i),y(i),c2_boundary(1,:)',c2_boundary(2,:)');
        if ~in
            Floe(i).alive = 0;
        end
        
%     if ~worked, display(['contact points issue for (' num2str(i) ', boundary)' ]); end
        if sum(abs(force_b))~=0
            [mm,~] = size(P_j);
            for ii =1:mm
                if abs(P_j(ii,2)) == Ly
                    force_b(ii,1) = 0;
                end
            end
%             force_b = [-sign(x(i)) -sign(y(i))].*abs(force_b);
            % boundary will be recorded as floe number Inf;
            Floe(i).interactions=[Floe(i).interactions ; Inf*ones(size(force_b,1),1) force_b P_j zeros(size(force_b,1),1) overlap'];
            Floe(i).OverlapArea = sum(overlap)+Floe(i).OverlapArea;
            Floe(i).potentialInteractions(end+1).floeNum = Inf;
            Floe(i).potentialInteractions(end).c = c2_boundary;
        end
    end
    
end
for i = 1:length(kill);
    if abs(kill(i)-i)>0 && kill(i)>0;
        transfer(kill(i))=i;
    end
end
% toc
live = cat(1,Floe.alive);
% if sum(live)<2
%     xx = 1; xx(1)=[1 2];
% end

% for i = 1+Nb:length(Floe)
%     if weld(i)>0 && Floe(i).alive > 0 && Floe(weld(i)).alive > 0
%         Floe(i).poly = polyshape(Floe(i).c_alpha'+[Floe(i).Xi Floe(i).Yi]);
%         Floe(weld(i)).poly = polyshape(Floe(weld(i)).c_alpha'+[Floe(weld(i)).Xi Floe(weld(i)).Yi]);
%         [floenew] = FuseFloes(Floe(i),Floe(weld(i)));
%         if floenew.h > 3
%             xx = 1;
%             xx(1) = [1 2];
%         elseif weld(i) > N0
%             xx = 1;
%             xx(1) = [1 2];
%         end
% %         if isfield(floenew,'poly')
% %             floenew=rmfield(floenew,{'poly'});
% %         end
%         Mass = [Floe(i).mass Floe(weld(i)).mass];
%         if Mass(1) > Mass(2)
%             floenew.interactions = Floe(i).interactions;
%             floenew.OverlapArea = Floe(i).OverlapArea;
%             floenew.potentialInteractions = Floe(i).potentialInteractions;
%             Floe(i) = floenew;
%             Floe(weld(i)).alive = 0; kill(weld(i)) = 0;
%             Floe(weld(i)).interactions = [];
%         else
%             floenew.interactions = Floe(weld(i)).interactions;
%             floenew.OverlapArea = Floe(weld(i)).OverlapArea;
%             floenew.potentialInteractions = Floe(weld(i)).potentialInteractions;
%             Floe(weld(i)) = floenew;
%             Floe(i).alive = 0; kill(i) = 0;
%             Floe(i).interactions = [];
%         end
%     end
% end
alive=cat(1,Floe.alive);
% if alive(1) == 0 || alive(2) == 0
%     xx = 1; xx(1)=[1 2];
% end
if isfield(Floe,'poly')
    Floe=rmfield(Floe,{'poly'});
end

%Fill the lower part of the interacton matrix (floe_i,floe_j) for floes with j<i
for i=1:N %this has to be done sequentially
      
    if ~isempty(Floe(i).interactions)
        
        a=Floe(i).interactions;
        
        indx=a(:,1);
        
        for j=1:length(indx)
            
            if indx(j)<=N && indx(j)>i
                Floe(indx(j)).interactions=[Floe(indx(j)).interactions; i -a(j,2:3) a(j,4:5) 0 a(j,7)];   % 0 is torque here that is to be calculated below
                Floe(indx(j)).OverlapArea = Floe(indx(j)).OverlapArea + a(j,7);
                m = size(Floe(indx(j)).potentialInteractions,2);
                Floe(indx(j)).potentialInteractions(m+1).floeNum=i;
                Floe(indx(j)).potentialInteractions(m+1).c=[Floe(i).c_alpha(1,:)+x(i); Floe(i).c_alpha(2,:)+y(i)];
                Floe(indx(j)).potentialInteractions(m+1).Ui=Floe(i).Ui;
                Floe(indx(j)).potentialInteractions(m+1).Vi=Floe(i).Vi;
                Floe(indx(j)).potentialInteractions(m+1).Xi=x(i);
                Floe(indx(j)).potentialInteractions(m+1).Yi=y(i);
                Floe(indx(j)).potentialInteractions(m+1).ksi_ice = Floe(i).ksi_ice;
            end
            
        end
%         [m,n] = size(a);
%         if m>1
%             xx = 1; xx(1) =[1 2];
%         end
    end

end

% for ii = 1:length(Floe)
%     if ~isempty(Floe(ii).interactions)
%         a = Floe(ii).interactions(:,1)-ii;
%         if min(abs(a)) == 0
%             xx = 1; xx(1) =[1 2];
%         end
%     end
% end

% live = cat(1,Floe.alive);
% if live(1) == 0 || live(2) == 0
%     xx = 1; xx(1)=[1 2];
% end

% calculate all torques from forces
if PERIODIC
    
%     for i=N0+1:N %do this in parfor
   parfor i=N0+1:N %do this in parfor
        
        if ~isempty(Floe(i).interactions)
            
            a=Floe(i).interactions;
            r=[x(i) y(i)];
            for k=1:size(a,1)
                floe_Rforce=a(k,4:5);
                floe_force=a(k,2:3);
                floe_torque=cross([floe_Rforce-r 0], [floe_force 0]);
                Floe(i).interactions(k,6)=floe_torque(3);
            end
            
            Floe(i).collision_force=sum(Floe(i).interactions(:,2:3),1);
            Floe(i).collision_torque=sum(Floe(i).interactions(:,6),1);
            
        end
        
    end
     %add forces and torques from ghost floes to their parents; ghost floes
    %begin with the index N0+1
    for i=1:length(parent)
        Floe(parent(i)).collision_force =Floe(parent(i)).collision_force +Floe(N0+i).collision_force;
        Floe(parent(i)).collision_torque=Floe(parent(i)).collision_torque+Floe(N0+i).collision_torque;
    end
end

% for ii = 1+Nb:length(Floe)
%     h1 = Floe(ii).mass/(Floe(ii).area*rho_ice);
%     if abs(Floe(ii).h -h1) > 0.05
%         xx = 1;
%         xx(1) = [1 2];
%     end
% end
live = cat(1,Floe.alive);
% if live(1) == 0 || live(2) == 0
%     xx = 1; xx(1)=[1 2];
% end
keep = ones(1,N0);
% for i=1+Nb:N0
parfor i=1+Nb:N0
    
    if ~isempty(Floe(i).interactions)
        
       a=Floe(i).interactions;
       r=[x(i) y(i)];
        for k=1:size(a,1)
            floe_Rforce=a(k,4:5);
            floe_force=a(k,2:3);
            floe_torque=cross([floe_Rforce-r 0], [floe_force 0]);
            Floe(i).interactions(k,6)=floe_torque(3);
        end
        
%        Floe(i).Stress =.5*([sum((a(:,4)-r(1)).*a(:,2)) sum((a(:,5)-r(2)).*a(:,2)); sum((a(:,4)-r(1)).*a(:,3)) sum((a(:,5)-r(2)).*a(:,3))]+[sum(a(:,2).*(a(:,4)-r(2))) sum(a(:,3).*(a(:,4)-r(2))); sum(a(:,2).*(a(:,5)-r(2))) sum(a(:,3).*(a(:,5)-r(2)))]);
       Floe(i).collision_force=sum(Floe(i).interactions(:,2:3),1)+Floe(i).collision_force;
       Floe(i).collision_torque=sum(Floe(i).interactions(:,6),1)+Floe(i).collision_torque;
        
    end
%     if Floe(1).collision_torque < 0 && Floe(2).collision_torque < 0
%         xx =1; xx(1) =[1 2];
%     end
    
    if PERIODIC
            
        if abs(Floe(i).Xi)>Lx %if floe got out of periodic bounds, put it on the other end
            Floe(i).Xi=Floe(i).Xi-2*Lx*sign(Floe(i).Xi);
        end
        
        if abs(Floe(i).Yi)>Ly %if floe got out of periodic bounds, put it on the other end
            Floe(i).Yi=Floe(i).Yi-2*Ly*sign(Floe(i).Yi);
        end
        
    end
    
   %Do the timestepping now that forces and torques are known.
%    FxOA = 0; FxExt = 0;FyOA = 0; FyExt = 0;
%     if Floe(i).alive && doInt.flag
%         [tmp,frac,FxOA,FyOA]=calc_trajectory_OA(dt,ocean,winds,Floe(i),doInt);
%         if (isempty(tmp) || isnan(x(i)) ), kill(i)=i; elseif frac == 1, keep(i) = 0; else Floe(i)=tmp; end
%     end

%     xx = 1; xx(1) =[1 2];
        %         [tmp,frac,Fx,Fy]=calc_trajectory_Nares(dt,ocean, winds,Floe(i),HFo,c2_boundary); % calculate trajectory
    if Floe(i).alive
        [tmp, frac,Fx,Fy] =calc_trajectory(dt,ocean,winds,Floe(i),HFo,doInt,c2_boundary, ubound,ucell,i);
%         h1 = tmp.mass/(tmp.area*rho_ice); 
%         if abs(tmp.h -h1) > 0.05 && tmp.alive == 1
%             xx = 1;
%             xx(1) = [1 2];
%         end
%         [tmp,frac,Fx,Fy]=calc_trajectory_Nares(dt,ocean, winds,Floe(i),HFo,doInt,c2_boundary);
        if (isempty(tmp) || isnan(x(i)) ), kill(i)=i;xx = 1; xx(1) =[1 2]; elseif frac == 1, keep(i) = 0; else; Floe(i)=tmp; Floe(i).Fx = Fx; Floe(i).Fy = Fy; end
%     if Floe(i).alive && ~isempty(Floe(i).interactions)
%         [tmp,FxExt,FyExt]=calc_trajectory_int(dt,ocean,Floe(i),HFo); % calculate trajectory
%         if (isempty(tmp) || isnan(x(i)) ), kill(i)=i; else Floe(i)=tmp; end
    end
%     Floe(i).Fx = FxOA+FxExt; Floe(i).Fy = FyOA+FyExt;
end
live = cat(1,Floe.alive);
uice = cat(1,Floe.Ui); vice = cat(1,Floe.Vi);

if max(abs(uice)) >100 || max(abs(vice)) >100
    save('FloeFailSpeed.mat','Floe', 'Floe0','kill','transfer','floebound', 'ubound', 'ucell', 'ocean', 'winds','c2_boundary','dt', 'HFo', 'min_floe_size', 'Nx','Ny','Nb');
     xx = 1; xx(1)=[1 2];
end
% if Floe(1).ksi_ice < 0 && Floe(2).ksi_ice < 0
%     xx =1; xx(1) =[1 2];
% end

% for i = 1:length(Floe)
%     if Floe(i).alive == 0
%         xx = 1; xx(1) =[1 2];
%     end
% end

% for ii = 1+Nb:length(Floe)
%     h1 = Floe(ii).mass/(Floe(ii).area*rho_ice);
%     if abs(Floe(ii).h -h1) > 0.05 && Floe(ii).alive == 1
%         xx = 1;
%         xx(1) = [1 2];
%     end
% end
%% 

%timer1 = tic;
floenew = [];
Ridge = zeros(1,length(Floe));
if RIDGING && doInt.flag
    %Create a function to control probability that ridging will occur
    h = cat(1,Floe.h);
    overlapArea=cat(1,Floe.OverlapArea)./cat(1,Floe.area);
%    keepR=rand(length(Floe),1)>5*overlapArea;%overlapArea>0;%
     keepR=rand(length(Floe),1)<0.05;
    for ii=1+Nb:N0
        
        if Floe(ii).alive && ~isempty(Floe(ii).interactions)
            a = Floe(ii).interactions;
            c1 = Floe(ii).c_alpha+[Floe(ii).Xi; Floe(ii).Yi];
            abound = zeros(1+Nb,1);
            if ~isempty(a)
                if ~isempty(InterX(c1,c2_boundary))
                    abound(1+Nb) = 1;
                end
                a(isinf(a(:,1)),:)=[];
            end

            if  ~keepR(ii) && h(ii)<5  && ~isempty(a)
                clear overlap;
                for jj = 1:size(a,1)
                    if a(jj,1) < length(Floe)+1
                        overlap(jj) = a(jj,7)/min([Floe(ii).area Floe(a(jj,1)).area]);
                    else
                        overlap(jj) = a(jj,7)/Floe(ii).area;
                    end
                end
                overlap(overlap<1e-6) = nan; overlap(overlap>0.95) = nan;
                overlappingFloes = a(~isnan(overlap),1);
                overlappingFloes = unique(overlappingFloes);
                abound(overlappingFloes<Nb+1) = 1;
                for jj = length(overlappingFloes):-1:1
                    if Ridge(overlappingFloes(jj))
                        overlappingFloes(jj)=[];
                    end
                end
                for jj = 1:length(overlappingFloes)
                    if Floe(overlappingFloes(jj)).h < 5
                        [Floe1, Floe2] = ridging(Floe(ii),Floe(overlappingFloes(jj)),c2_boundary_poly,PERIODIC,min_floe_size);
                        %xx = 1; xx(1) =[1 2];
                        if length(Floe1) > 1
                            Floe(ii) = Floe1(1);
                            Ridge(ii) = 1;
                            floenew = [floenew Floe1(2:end)];
                        else
                            Floe(ii) = Floe1;
                            if Floe1.alive == 0
                                kill(ii) = ii;
                            end
                        end
                        if length(Floe2) > 1
                            Floe(overlappingFloes(jj)) = Floe2(1);
                            Ridge(overlappingFloes(jj)) = 1;
                            floenew = [floenew Floe2(2:end)];
                        else
                            Floe(overlappingFloes(jj)) = Floe2;
                            if Floe2.alive == 0 && overlappingFloes(jj) <= N0
                                kill(overlappingFloes(jj)) = overlappingFloes(jj);
                            end
                        end
                    end
                end

            end
            if sum(abound)>0 && h(ii)<1.25 && Floe(ii).area > min_floe_size
                for jj = 1:length(abound)
                    if abound(jj) == 1 && jj == Nb+1
                        [Floe1, ~] = ridging(Floe(ii),floebound,c2_boundary_poly,PERIODIC,min_floe_size);
                        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
%                         if area(intersect(poly,c2_boundary_poly))/Floe(ii).area < 0.95
%                             xx = 1; xx(1) =[1 2];
%                         end
                    elseif abound(jj)  == 1
                        poly = polyshape([Floe(abound(jj)).c_alpha(1,:)+Floe(abound(jj)).Xi; Floeabound(jj).c_alpha(2,:)+Floe(abound(jj)).Yi]');
                        [Floe1, ~] = ridging(Floe(ii),Floe(abound(jj)),poly,PERIODIC,min_floe_size);
                    end
                    if length(Floe1) > 1
                        Floe(ii) = Floe1(1);
                        floenew = [floenew Floe1(2:end)];
                    else
                        Floe(ii) = Floe1;
                        if Floe1.alive == 0
                            kill(ii) = ii;
                        end
                    end
                end
            end
        end
    end
end
%toc(timer1)
uice = cat(1,Floe.Ui); vice = cat(1,Floe.Vi);

if max(abs(uice)) >100 || max(abs(vice)) >100
    save('FloeFailSpeed.mat','Floe', 'Floe0','kill','transfer','floebound', 'ubound', 'ucell', 'ocean', 'winds','c2_boundary','dt', 'HFo', 'min_floe_size', 'Nx','Ny','Nb');
     xx = 1; xx(1)=[1 2];
end

Raft = zeros(1,length(Floe));
if RAFTING && doInt.flag
    %Create a function to control probability that ridging will occur
    h = cat(1,Floe.h);
    overlapArea=cat(1,Floe.OverlapArea)./cat(1,Floe.area);
    keepR=rand(length(Floe),1)>0.5*overlapArea;%overlapArea>0;%
%     keep=rand(length(Floe),1)<0.5;
    for ii=1+Nb:N0
        
        if Floe(ii).alive && ~isempty(Floe(ii).interactions)
            a = Floe(ii).interactions;
            c1 = Floe(ii).c_alpha+[Floe(ii).Xi; Floe(ii).Yi];
            abound = zeros(1+Nb,1);
            if ~isempty(a)
                if ~isempty(InterX(c1,c2_boundary))
                    abound(1+Nb) = 1;
                end
                a(isinf(a(:,1)),:)=[];
            end

            if  ~keepR(ii) && h(ii)<0.25  && ~isempty(a)
                clear overlap;
                for jj = 1:size(a,1)
                    if a(jj,1) < length(Floe)+1
                        overlap(jj) = a(jj,7)/min([Floe(ii).area Floe(a(jj,1)).area]);
                    else
                        overlap(jj) = a(jj,7)/Floe(ii).area;
                    end
                end
                overlap(overlap<1e-6) = nan; overlap(overlap>0.95) = nan;
                overlappingFloes = a(~isnan(overlap),1);
                overlappingFloes = unique(overlappingFloes);
                abound(overlappingFloes<Nb+1) = 1;
                for jj = length(overlappingFloes):-1:1
                    if Raft(overlappingFloes(jj))
                        overlappingFloes(jj)=[];
                    end
                end
                for jj = 1:length(overlappingFloes)
                    if Floe(overlappingFloes(jj)).h < 0.25
                        [Floe1, Floe2] = rafting(Floe(ii),Floe(overlappingFloes(jj)),c2_boundary_poly,PERIODIC,min_floe_size);
                        
                        if length(Floe1) > 1
                            Floe(ii) = Floe1(1);
                            Raft(ii) = 1;
                            floenew = [floenew Floe1(2:end)];
                        else
                            Floe(ii) = Floe1;
                            if Floe1.alive == 0
                                kill(ii) = ii;
                            end
                        end
                        if length(Floe2) > 1
                            Floe(overlappingFloes(jj)) = Floe2(1);
                            Raft(overlappingFloes(jj)) = 1;
                            floenew = [floenew Floe2(2:end)];
                        else
                            Floe(overlappingFloes(jj)) = Floe2;
                            if Floe2.alive == 0 && overlappingFloes(jj) <= N0
                                kill(overlappingFloes(jj)) = overlappingFloes(jj);
                            end
                        end
                    end
                end

            end
            if sum(abound)>0 && h(ii)<0.25 && Floe(ii).area > min_floe_size
                for jj = 1:length(abound)
                    if abound(jj) == 1 && jj == Nb+1
                        [Floe1, ~] = rafting(Floe(ii),floebound,c2_boundary_poly,PERIODIC,min_floe_size);
                        poly = polyshape(Floe(ii).c_alpha'+[Floe(ii).Xi Floe(ii).Yi]);
%                         if area(intersect(poly,c2_boundary_poly))/Floe(ii).area < 0.95
%                             xx = 1; xx(1) =[1 2];
%                         end
                    elseif abound(jj)  == 1
                        poly = polyshape([Floe(abound(jj)).c_alpha(1,:)+Floe(abound(jj)).Xi; Floeabound(jj).c_alpha(2,:)+Floe(abound(jj)).Yi]');
                        [Floe1, ~] = rafting(Floe(ii),Floe(abound(jj)),poly,PERIODIC,min_floe_size);
                    end
                    if length(Floe1) > 1
                        Floe(ii) = Floe1(1);
                        floenew = [floenew Floe1(2:end)];
                    else
                        Floe(ii) = Floe1;
                        if Floe1.alive == 0
                            kill(ii) = ii;
                        end
                    end
                end
            end
        end
    end
end
uice = cat(1,Floe.Ui); vice = cat(1,Floe.Vi);

if max(abs(uice)) >100 || max(abs(vice)) >100
    save('FloeFailSpeed.mat','Floe', 'Floe0','kill','transfer','floebound', 'ubound', 'ucell', 'ocean', 'winds','c2_boundary','dt', 'HFo', 'min_floe_size', 'Nx','Ny','Nb');
     xx = 1; xx(1)=[1 2];
end
Floe=Floe(1:N0); % ditch the ghost floes.
% for ii = 1+Nb:length(Floe)
%     h1 = Floe(ii).mass/(Floe(ii).area*rho_ice);
%     if abs(Floe(ii).h -h1) > 0.05 && Floe(ii).alive == 1
%         xx = 1;
%         xx(1) = [1 2];
%     end
% end

killO = kill; transferO = transfer; FloeO = Floe;

if ~isempty(kill(kill>0)) 
    kill(kill>N0)=0;
    transfer(transfer>N0) = 0;
    transfer = transfer(kill>0);
    kill = kill(kill>0);
    for ii = 1:length(kill)
        if Floe(kill(ii)).alive>0 
            if transfer(ii)>0 && (Floe(kill(ii)).area>2e4 || Floe(kill(ii)).area>2e4)
%                 xx = 1; xx(1) =[1 2];
                Floe1 = Floe(kill(ii));
                Floe2 = Floe(transfer(ii));
                Floe1.poly = polyshape(Floe1.c_alpha'+[Floe1.Xi Floe1.Yi]);
                Floe2.poly = polyshape(Floe2.c_alpha'+[Floe2.Xi Floe2.Yi]);
                floes  = FuseFloes(Floe1,Floe2);
                uice = cat(1,floes.Ui); vice = cat(1,floes.Vi);
                if max(abs(uice)) >100 || max(abs(vice)) >100
                    save('FloeFailSpeed.mat','Floe1', 'Floe2');
                     xx = 1; xx(1)=[1 2];
                end
                if isfield(floes,'poly')
                    floes=rmfield(floes,{'poly'});
                end
                if length(floes)>1
                    Floe(transfer(ii)) = floes(1);
                    for jj = 2:length(floes)
                        floenew = [floenew floes(2:end)];
                    end
                elseif isempty(floes)
                    save('FloeTransfer.mat','Floe','kill','transfer','Floe1','Floe2')
                else
                    Floe(transfer(ii)) = floes(1);
                end
%                 k = transfer(ii);
%                 hold = Floe(k).h;
%                 V = Floe(ii).mass/rho_ice;
%                 Floe(k).h = Floe(k).h + V/Floe(k).area;
%                 Floe(k).mass = Floe(k).mass+Floe(ii).mass;
%                 Floe(k).inertia_moment = Floe(k).h/hold.*Floe(k).inertia_moment;
            end
            dissolvedNEW = dissolvedNEW+calc_dissolved_mass(Floe(kill(ii)),Nx,Ny,c2_boundary_poly);
            Floe(kill(ii)).alive = 0;
        end
    end
end
Floe = [Floe floenew];
live = cat(1,Floe.alive);
% if sum(live)<2
%     xx = 1; xx(1)=[1 2];
% end
Floe(live==0)=[]; %remove any floes that got dissolved so they do not take up space
% notalive = logical(abs(live-1));
% keep = logical(keep+notalive);
% fracturedFloes=fracture_floe(Floe(~keep),3);
% if ~isempty(fracturedFloes)
%     Floe=[Floe(keep) fracturedFloes];
% end
for ii = 1:length(Floe)
    if isempty(Floe(ii).potentialInteractions) && ~isempty(Floe(ii).interactions)
        xx = 1;
        xx(1) =[1 2];
    end
end

Floe=rmfield(Floe,{'potentialInteractions'});

uice = cat(1,Floe.Ui); vice = cat(1,Floe.Vi);

if max(abs(uice)) >100 || max(abs(vice)) >100
    save('FloeFailSpeed.mat','Floe', 'Floe0','kill','transfer','floebound', 'ubound', 'ucell', 'ocean', 'winds','c2_boundary','dt', 'HFo', 'min_floe_size', 'Nx','Ny','Nb','killO','transferO','FloeO');
     xx = 1; xx(1)=[1 2];
end

warning('on',id)
warning('on',id3)
end
