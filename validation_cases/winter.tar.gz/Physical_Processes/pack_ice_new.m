function [Floe,Vd] = pack_ice_new(Floe,c2_boundary,dhdt,Vd,target,ocean, height, min_floe_size, PERIODIC,Nx,Ny)
%% This function takes in the existing floe state and creates new thin floes in the open space to match the input target concentration
id = 'MATLAB:polyshape:tinyBoundaryDropped';
warning('off',id);
id2 ='MATLAB:polyshape:repairedBySimplify';
warning('off',id2)

save('floepack.mat','Floe','c2_boundary','dhdt','Vd','target','ocean', 'height', 'min_floe_size', 'PERIODIC','Nx','Ny');

alive = cat(1,Floe.alive);
Floe(~logical(alive)) = [];
Fold = Floe;
for kk = 1:length(Floe)
    Fold(kk).poly = polyshape(Fold(kk).c_alpha'+[Fold(kk).Xi Fold(kk).Yi]);
end

N0=length(Floe);
Lx= max(c2_boundary(1,:));
Ly= max(c2_boundary(2,:));%c2 must be symmetric around x=0 for channel boundary conditions.

%If the floe is periodic populate the ghost floes
N0=length(Floe);
if PERIODIC
    
    ghostFloeX=[];
    ghostFloeY=[];
    parent=[];
    translation = [];
    
    x=cat(1,Floe.Xi);
    y=cat(1,Floe.Yi);
    alive=cat(1,Floe.alive);
    
    for i=1:length(Floe)
        poly = polyshape(Floe(i).c_alpha'+[x(i) y(i)]);
        if alive(i) && (max(abs(poly.Vertices(:,1)))>Lx)
            
            ghostFloeX=[ghostFloeX  Floe(i)];
            ghostFloeX(end).Xi=Floe(i).Xi-2*Lx*sign(x(i));
            parent=[parent  i];
            translation = [translation; -2*Lx*sign(x(i)) 0];
            
        end
        
    end
    
    Floe=[Floe ghostFloeX];
    
    x=cat(1,Floe.Xi);
    y=cat(1,Floe.Yi);
    alive=cat(1,Floe.alive);
    
    for i=1:length(Floe)
        poly = polyshape(Floe(i).c_alpha'+[x(i) y(i)]);
        if alive(i) && (max(abs(poly.Vertices(:,2)))>Ly)
            
            ghostFloeY=[ghostFloeY  Floe(i)];
            ghostFloeY(end).Yi=Floe(i).Yi-2*Ly*sign(y(i));
            parent=[parent  i];
            translation = [translation; 0 -2*Ly*sign(y(i))];
            
        end
        
    end
    
    Floe=[Floe ghostFloeY];
    
end

%Caclulate the coarse grid and any potential interactions for the different
%regions of the floe where ice needs to be created
floenew = [];
rho_ice = 920;
x = min(c2_boundary(1,:)):(max(c2_boundary(1,:))-min(c2_boundary(1,:)))/Nx:max(c2_boundary(1,:));
y = min(c2_boundary(2,:)):(max(c2_boundary(2,:))-min(c2_boundary(2,:)))/Ny:max(c2_boundary(2,:));
y = fliplr(y);
dx = abs(x(2)-x(1));
dy = abs(y(2)-y(1));
[xx,yy] = meshgrid(0.5*(x(1:end-1)+x(2:end)),0.5*(y(1:end-1)+y(2:end)));
xf = cat(1,Floe.Xi);
yf = cat(1,Floe.Yi);
r_max = sqrt((dx/2)^2+(dy/2)^2);
rmax = cat(1,Floe.rmax);
potentialInteractions = zeros(Ny,Nx,length(Floe));


for kk = 1:length(Floe)
    Floe(kk).poly = polyshape(Floe(kk).c_alpha'+[Floe(kk).Xi Floe(kk).Yi]);
    pint = sqrt((xx-xf(kk)).^2+(yy-yf(kk)).^2)-(rmax(kk)+r_max);
    pint(pint>0) = 0;
    pint(pint<0) = 1;
    potentialInteractions(:,:,kk) = pint;
end

%function to determine the probablity that ice gets created
SimpMin = @(A) 3*log10(A);

%% Loop through all regions creating sea ice in each if probability criteria is met
for j = 1:Nx*Ny
    FloePack(j).floenew = [];
    %FloePack(j).subfloes = [];
    kill(j).floes = [];
    floe2(j).floe = [];
end
parfor j = 1:Nx*Ny

    count = 1;
    
    ii = ceil(j/Ny);
    jj = mod(j,Ny);
    if jj == 0;  jj = Ny; end
    
    %Find coverage of sea ice in region of interest and calculate concentration
    bound = [x(ii) x(ii) x(ii+1) x(ii+1) x(ii);y(jj) y(jj+1) y(jj+1) y(jj) y(jj)];
    box = polyshape(bound(1,:), bound(2,:));
    k = find(logical(potentialInteractions(jj,ii,:))==1);
    if isempty(k)
        poly = [];
        A = 0;
        inBox = [];
    else
        poly = intersect(box,[Floe(logical(potentialInteractions(jj,ii,:))).poly]);
        A = area(poly);
        inBox = k(A>0);
        poly = [Floe(inBox).poly];
        Atot = area(poly);
    end
    
    c = sum(A)/area(box);
    
    %if concentration is below target then create new sea ice
    if c<0.99*target
        atarget = target*area(box);
        %floe.poly = box;
        
        %Break up open water into chunks that will be the new floes
        [Xi,Yi] = centroid(box);
        %floe.Xi = Xi; floe.Yi = Yi;
        N = ceil(atarget/(50*min_floe_size));
        if N < 3
            N = 3;
        elseif N > 5
            N = 5;
        end
        
        X = Xi+r_max*(2*rand(N,1)-1);
        Y = Yi+r_max*(2*rand(N,1)-1);
        boundingbox=[-1 ,-1; 1,-1; 1,1; -1 ,1]*r_max+ [Xi Yi];
        [~, b,~,~,~] = polybnd_voronoi([X Y],boundingbox);
        
%         for kk = 1:length(b)
%             if ~isnan(b{kk})
%                 FloePack(j).subfloes(kk) = polyshape(b{kk});
%             end
%         end
        
        subfloes = [];
        for kk = 1:length(b)
            new = subtract(polyshape(b{kk}),poly);
            new = intersect(new);
            new = intersect(new,box);
            for iii = 1:length(new)
                R = regions(new(iii));
                subfloes = [subfloes; R(area(R)>min_floe_size)];
            end
        end
        
        %Add in new floes until we reach target concentration
        for iii = 1:length(subfloes)
            
            polyFull = rmholes(subfloes(iii));
            for jjj = 1:length(polyFull)
                if subfloes(iii).NumHoles > 0
                    hnew.mean = area(subfloes(iii))*height.mean/area(polyFull(jjj));
                    hnew.delta = height.delta;
                    floe2(j).floe = initialize_floe_values(polyFull(jjj),hnew);
                else
                    floe2(j).floe = initialize_floe_values(polyFull(jjj),height);
                end
                
                if subfloes(iii).NumHoles > 0
                    poly2 = rmholes(floe2(j).floe.poly);
                    live = cat(1,Floe.alive);
                    if sum(area(intersect(poly2,[Floe(live==1).poly])))>0
                        %k2 = find(logical(potentialInteractions(jj,ii,:))==1);
                        polyO = intersect(poly2,[Floe(inBox).poly]);
                        A2 = area(polyO);
                        polyin = A2./Atot;
                        in = inBox(polyin>0.99);
                        in = flipud(in);
                        kill(j).floes = [kill(j).floes; in];
                        for kk = 1:length(in)
                            floe2(j).floe = FuseFloes(floe2(j).floe,Floe(in(kk)));
                            if length(floe2(j).floe) > 1
                                [~,I] = max(cat(1,floe2(j).floe.area));
                                tmp = floe2(j).floe(I);
                                floe2(j).floe(I) = [];
                                FloePack(j).floenew = [FloePack(j).floenew floe2(j).floe];
                                floe2(j).floe = tmp;
                            end
                            %Floe(in(kk)).alive = 0;
                            %kill(j).floes(count) = in(kk);
                            count = count+1;
                        end
%                         xx = 1; xx(1) =[1 2];
                    end
                end
                if subfloes(iii).NumHoles > 0
                    hnew = height;
                    hnew.mean = floe2(j).floe.h;
                    floe2(j).floe = initialize_floe_values(poly2,hnew);
                end
                
                FloePack(j).floenew = [FloePack(j).floenew floe2(j).floe];
                floe2(j).floe = [];
            end
        end

    end
    
end
Floe=Floe(1:N0);
killFloes = [];
floenew = [];
for ii = 1:length(kill)
    killFloes = [killFloes; kill(ii).floes];
    floenew = [floenew FloePack(ii).floenew];
end
if ~isempty(killFloes)
    killFloes = unique(killFloes(killFloes>0));
    killFloes = sort(killFloes,'descend');
    for ii = 1:length(killFloes)
        Floe(killFloes(ii)).alive = 0;
    end
end
alive = cat(1,Floe.alive);
Floe(alive==0) = [];
if isfield(floenew,'potentialInteractions')
    floenew=rmfield(floenew,{'potentialInteractions'});
end

Floe = [Floe floenew];
warning('on',id)
warning('on',id2)

% xx = 1; xx(1) =[1 2];
Floe=rmfield(Floe,{'poly'});
Vd(Vd<0)=0;

end