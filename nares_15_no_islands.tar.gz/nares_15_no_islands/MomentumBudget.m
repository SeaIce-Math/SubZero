close all

load winds_aws_may.mat;
winds_u = winds_u(385:1041);
winds_v = winds_v(385:1041);
time_obs = time_obs(385:1041)-time_obs(385);
nDTOut = 250; dt = 5; nSnap = 692;

% ice-ocean parameters
rho_ice=920; % kg/m3
rho0=1027;   % ocean density
Cd=3e-3;

% ice-water drag coefficient
rho_air=1.2;
Cd_atm=1e-3;
turn_angle = 0.2618;

coast = zeros(1,nSnap); Atm = coast; Ocn = coast; 
islands = zeros(4,nSnap); island = coast;
%load(['./Floe0000244.mat'],'Floe','Nb'); jj = 244;
for jj = 1:nSnap
    load(['/dat1/bpm5026/nares_medium2/FloesPaperNew/Floe' num2str(jj,'%07.f') '.mat'],'Floe','Nb');

    FloeL = [];
    keep = zeros(1,length(Floe));
    for ii = 1+Nb:length(Floe)
        if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-2.5e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1e5 && min(Floe(ii).c_alpha(1,:))+Floe(ii).Xi>-5e4 && max(Floe(ii).c_alpha(1,:))+Floe(ii).Xi<5e4
            FloeL = [FloeL Floe(ii)];
            keep(ii) = 1;
        end
    end
    Floe = FloeL;

    if Nb == 21
        for ii = 1:length(Floe)
            a=Floe(ii).interactions;
            if ~isempty(a)
                Nums = a(:,1);
                keep_coast = logical(Nums<Nb+1);
                a_coast = a(keep_coast,:);
                if ~isempty(a_coast)
                    coast(jj) = coast(jj)+sum(a_coast(:,3));
                end
            end
        end
    else
        for ii = 1:length(Floe)
            a=Floe(ii).interactions;
            if ~isempty(a)
                Nums = a(:,1);
                keep_islands = logical(Nums<5);
                keep_coast = logical(Nums<Nb+1); keep_coast(Nums<5)=0;
                a_coast = a(keep_coast,:);
                a_islands = a(keep_islands,:);
                if ~isempty(a_islands)
                    islands(ii,jj) = islands(a_islands(1),jj)+sum(a_islands(:,3));
                end
                if ~isempty(a_coast)
                    coast(jj) = coast(jj)+sum(a_coast(:,3));
                end
            end
        end
    end

    i_step = (jj-1)*nDTOut;
    Time = i_step*dt;t_obs = time_obs-Time;
    t_obs(t_obs<=0) = inf; [~,count] = min(t_obs);
    U10 = winds_u(count); V10 = winds_v(count);

    Fy_atm=rho_air*Cd_atm*sqrt(U10^2+V10^2)*V10;
    A = cat(1,Floe.area);
    Atm(jj) = sum(Fy_atm*A);

    du=-cat(1,Floe.Ui); dv=-0.4-cat(1,Floe.Vi);
    tau_ocnY=rho0*Cd*sqrt(du.^2+dv.^2).*(sin(turn_angle)*du+cos(turn_angle)*dv);
    Ocn(jj) = sum(tau_ocnY.*A);
end

% island = sum(islands,1);
% dpdt = Ocn + Atm + coast + island;
% time = nDTOut*dt*((1:nSnap) - 1)/3600;
% subplot(1,2,1)
% plot(time, dpdt)
% hold on
% plot(time, Atm)
% plot(time, Ocn)
% plot(time, island)
% plot(time, coast)
% legend('dpdt','Atm','Ocn','island','coast')

coast2 = zeros(1,nSnap); Atm2 = coast2; Ocn2 = coast2;
islands2 = zeros(4,nSnap); island2 = coast2;
for jj = 1:nSnap
    load(['/dat1/bpm5026/nares_medium_no_islands/FloesPaperNew/Floe' num2str(jj,'%07.f') '.mat'],'Floe','Nb');

    FloeL = [];
    keep = zeros(1,length(Floe));
    for ii = 1+Nb:length(Floe)
        if min(Floe(ii).c_alpha(2,:))+Floe(ii).Yi>-2.5e5 && max(Floe(ii).c_alpha(2,:))+Floe(ii).Yi<-1e5 && min(Floe(ii).c_alpha(1,:))+Floe(ii).Xi>-5e4 && max(Floe(ii).c_alpha(1,:))+Floe(ii).Xi<5e4
            FloeL = [FloeL Floe(ii)];
            keep(ii) = 1;
        end
    end
    Floe = FloeL;

    if Nb == 21
        for ii = 1:length(Floe)
            a=Floe(ii).interactions;
            if ~isempty(a)
                Nums = a(:,1);
                keep_coast = logical(Nums<Nb+1);
                a_coast = a(keep_coast,:);
                if ~isempty(a_coast)
                    coast2(jj) = coast2(jj)+sum(a_coast(:,3));
                end
            end
        end
    else
        for ii = 1:length(Floe)
            a=Floe(ii).interactions;
            if ~isempty(a)
                Nums = a(:,1);
                keep_islands = logical(Nums<5);
                keep_coast = logical(Nums<Nb+1); keep_coast(Nums<5)=0;
                a_coast = a(keep_coast,:);
                a_islands = a(keep_islands,:);
                if ~isempty(a_islands)
                    islands2(ii,jj) = islands2(a_islands(1),jj)+sum(a_islands(:,3));
                end
                if ~isempty(a_coast)
                    coast2(jj) = coast2(jj)+sum(a_coast(:,3));
                end
            end
        end
    end

    i_step = (jj-1)*nDTOut;
    Time = i_step*dt;t_obs = time_obs-Time;
    t_obs(t_obs<=0) = inf; [~,count] = min(t_obs);
    U10 = winds_u(count); V10 = winds_v(count);

    Fy_atm=rho_air*Cd_atm*sqrt(U10^2+V10^2)*V10;
    A = cat(1,Floe.area);
    Atm2(jj) = sum(Fy_atm*A);

    du=-cat(1,Floe.Ui); dv=-0.4-cat(1,Floe.Vi);
    tau_ocnY=rho0*Cd*sqrt(du.^2+dv.^2).*(sin(turn_angle)*du+cos(turn_angle)*dv);
    Ocn2(jj) = sum(tau_ocnY.*A);
end

dt = 5;
time = nDTOut*dt*((1:nSnap) - 1)/3600;

save('MomentumBudget.mat','time','Ocn','Atm','coast','islands','Ocn2','Atm2','coast2','islands2')
% island2 = sum(islands2,1);
% dpdt2 = Ocn2 + Atm2 + coast2 + island2;
% time = nDTOut*dt*((1:nSnap) - 1)/3600;
% subplot(1,2,2)
% plot(time, dpdt2)
% hold on
% plot(time, Atm2)
% plot(time, Ocn2)
% plot(time, island2)
% plot(time, coast2)
% legend('dpdt','Atm','Ocn','island','coast')
% 
% figure
% plot(time,islands(1,:))
% hold on
% plot(time,islands(2,:))
% plot(time,islands(3,:))
% 
% figure
% subplot(1,2,1)
% x = ["dpdt"; "Atm"; "Ocn"; "Islands"; "Coast"];
% y = [mean(dpdt(150:end)) mean(dpdt2(150:end)); mean(Atm(150:end)) mean(Atm2(150:end)); mean(Ocn(150:end)) mean(Ocn2(150:end)); mean(island(150:end)) mean(island2(150:end)); mean(coast(150:end)) mean(coast2(150:end))];
% bar(x,y)
% %subplot(1,2,2)
% %x = ["dpdt" "Atm" "Ocn" "Islands" "Coast"];
% %y = [mean(dpdt2(150:end)) mean(Atm2(150:end)) mean(Ocn2(150:end)) mean(island2(150:end)) mean(coast2(150:end))];
% %bar(x,y)
% lgd = legend('islands','no islands');
% fontsize(lgd,18,'points');
% set(gca,'fontsize',18);
% legend('box','off')
% ylabel('Force (N)','fontsize',20)
% 
% subplot(1,2,2)
% t_pre = time; t_pre(time>30) = 0;t_pre(time<30) = 1; t_pre = logical(t_pre);
% x = ["Hans"; "Franklin"; "Crozier"];
% y = [mean(islands(1,t_pre)) mean(islands(1,~t_pre)); mean(islands(2,t_pre)) mean(islands(2,~t_pre)); mean(islands(3,t_pre)) mean(islands(3,~t_pre))];
% bar(x,y)
% lgd = legend('Pre-collapse','Post-collapse');
% fontsize(lgd,18,'points');
% set(gca,'fontsize',18);
% legend('box','off')
% ylabel('Force (N)','fontsize',20)
% 
% % %% 
% % island = sum(islands,1);
% % dpdt = Ocn + Atm + coast + island;
% % close all
% % figure
% % subplot(1,2,1)
% % x = ["dpdt"; "Atm"; "Ocn"; "Islands"; "Coast"];
% % y = [mean(dpdt(jj)); mean(Atm(jj)); mean(Ocn(jj)); mean(island(jj)); mean(coast(jj))];
% % bar(x,y)
% % %subplot(1,2,2)
% % %x = ["dpdt" "Atm" "Ocn" "Islands" "Coast"];
% % %y = [mean(dpdt2(150:end)) mean(Atm2(150:end)) mean(Ocn2(150:end)) mean(island2(150:end)) mean(coast2(150:end))];
% % %bar(x,y)
% % %lgd = legend('islands','no islands');
% % %fontsize(lgd,18,'points');
% % set(gca,'fontsize',18);
% % legend('box','off')
% % ylabel('Force (N)','fontsize',20)
% % 
% % subplot(1,2,2)
% % x = ["Hans"; "Franklin"; "Crozier"];
% % y = [mean(islands(1,jj)); mean(islands(2,jj)); mean(islands(3,jj))];
% % bar(x,y)
% % %lgd = legend('Pre-collapse','Post-collapse');
% % %fontsize(lgd,18,'points');
% % set(gca,'fontsize',18);
% % legend('box','off')
% % ylabel('Force (N)','fontsize',20)
